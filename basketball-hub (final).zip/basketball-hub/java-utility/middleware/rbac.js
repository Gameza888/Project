function hasRole(role) {
  return (req, res, next) => {
    const roles = req.user?.roles || [];
    if (roles.includes('admin') || roles.includes(role)) return next();
    return res.status(403).json({ error: 'Forbidden' });
  };
}

module.exports = { hasRole };
