const express = require('express');
const pool = require('../db');
const { requireAuth } = require('../middleware/auth');
const { hasRole } = require('../middleware/rbac');

const router = express.Router();

router.get('/', async (_req, res) => {
  const { rows } = await pool.query('SELECT * FROM teams ORDER BY name');
  res.json(rows);
});

router.post('/', requireAuth, hasRole('admin'), async (req, res) => {
  const { name, city, short_code } = req.body;
  const { rows } = await pool.query(
    `INSERT INTO teams(name, city, short_code) VALUES ($1,$2,$3) RETURNING *`,
    [name, city, short_code]
  );
  res.status(201).json(rows[0]);
});

module.exports = router;
