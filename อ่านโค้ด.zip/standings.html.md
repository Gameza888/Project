# standings.html — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `<!DOCTYPE html>` | ประกาศชนิดเอกสาร HTML5 |
| 2 | `<html lang="th">` | แท็ก `<html>` ครอบทั้งเอกสาร และกำหนดภาษา |
| 3 | `  <head>` | หัวเอกสาร: meta, title, link, script ที่ไม่แสดงตรงๆ |
| 4 | `    <meta charset="utf-8" />` | กำหนดเมตาดาต้า (เช่น charset) |
| 5 | `    <title>Standings</title>` | กำหนดชื่อหน้า (แสดงบนแท็บเบราว์เซอร์) |
| 6 | `    <link rel="stylesheet" href="css/style.css" />` | ลิงก์ไฟล์ภายนอก (เช่น CSS) |
| 7 | `    <style>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 8 | `      .guest-message{` | แท็ก/ข้อความ HTML อื่น ๆ |
| 9 | `        padding:16px;color:#444;margin-top:8px` | แท็ก/ข้อความ HTML อื่น ๆ |
| 10 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 11 | `      table{width:100%}` | แท็ก/ข้อความ HTML อื่น ๆ |
| 12 | `      th,td{padding:6px 8px}` | แท็ก/ข้อความ HTML อื่น ๆ |
| 13 | `    </style>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 14 | `  </head>` | ปิดส่วน head |
| 15 | `  <body>` | ส่วนเนื้อหาเพจที่จะมองเห็น |
| 16 | `    <div id="nav"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 17 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 18 | `    <main id="standingsPane">` | แท็ก/ข้อความ HTML อื่น ๆ |
| 19 | `      <h1>Standings</h1>` | หัวข้อข้อความ |
| 20 | `      <table id="standingsTable">` | ตารางข้อมูล |
| 21 | `        <thead>` | ตารางข้อมูล |
| 22 | `          <tr>` | ตารางข้อมูล |
| 23 | `            <th>#</th>` | ตารางข้อมูล |
| 24 | `            <th>Team</th>` | ตารางข้อมูล |
| 25 | `            <th>GP</th>` | ตารางข้อมูล |
| 26 | `            <th>W</th>` | ตารางข้อมูล |
| 27 | `            <th>L</th>` | ตารางข้อมูล |
| 28 | `            <th>PF</th>` | ตารางข้อมูล |
| 29 | `            <th>PA</th>` | ตารางข้อมูล |
| 30 | `            <th>Diff</th>` | ตารางข้อมูล |
| 31 | `            <th>Win%</th>` | ตารางข้อมูล |
| 32 | `          </tr>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 33 | `        </thead>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 34 | `        <tbody id="standingsBody"></tbody>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 35 | `      </table>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 36 | `    </main>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 37 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 38 | `    <script src="_common.js"></script>` | ฝัง/ลิงก์สคริปต์ JavaScript |
| 39 | `    <script>` | ฝัง/ลิงก์สคริปต์ JavaScript |
| 40 | `      // Navbar + logout` | แท็ก/ข้อความ HTML อื่น ๆ |
| 41 | `      document.getElementById("nav").innerHTML = navBar("standings");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 42 | `      bindLogout();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 43 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 44 | `      // --- Guest gate: ซ่อนทั้ง pane แล้วแสดงข้อความแทน ---` | แท็ก/ข้อความ HTML อื่น ๆ |
| 45 | `      if (!me()) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 46 | `        const pane = document.getElementById("standingsPane");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 47 | `        if (pane) pane.style.display = "none";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 48 | `        document.body.insertAdjacentHTML(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 49 | `          "beforeend",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 50 | `          `<div class="guest-message">ต้องเข้าสู่ระบบก่อนเพื่อดูข้อมูล</div>`` | แท็ก/ข้อความ HTML อื่น ๆ |
| 51 | `        );` | แท็ก/ข้อความ HTML อื่น ๆ |
| 52 | `        // จบที่นี่ ไม่โหลดข้อมูลอื่น` | แท็ก/ข้อความ HTML อื่น ๆ |
| 53 | `      } else {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 54 | `        loadStandings();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 55 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 56 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 57 | `      // ---- helpers ----` | แท็ก/ข้อความ HTML อื่น ๆ |
| 58 | `      async function fetchJSON(url, opt = {}) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 59 | `        const r = await fetch(url, opt);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 60 | `        if (!r.ok) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 61 | `          let msg = `HTTP ${r.status}`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 62 | `          try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 63 | `            const d = await r.json();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 64 | `            msg = d.error \|\| d.message \|\| msg;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 65 | `          } catch {}` | แท็ก/ข้อความ HTML อื่น ๆ |
| 66 | `          throw new Error(msg);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 67 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 68 | `        try { return await r.json(); } catch { return null; }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 69 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 70 | `      const n = x => Number(x \|\| 0);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 71 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 72 | `      // ---- main loader ----` | แท็ก/ข้อความ HTML อื่น ๆ |
| 73 | `      async function loadStandings() {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 74 | `        try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 75 | `          const rows = await fetchJSON("/api/standings", {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 76 | `            headers: { ...authHeaders() }   // เผื่อ API ต้องการ token` | แท็ก/ข้อความ HTML อื่น ๆ |
| 77 | `          });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 78 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 79 | `          const body = document.getElementById("standingsBody"); // <- id ถูกต้อง` | แท็ก/ข้อความ HTML อื่น ๆ |
| 80 | `          body.innerHTML =` | แท็ก/ข้อความ HTML อื่น ๆ |
| 81 | `            (rows \|\| []).map((s, i) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 82 | `              const gp   = Number(s.games_played\|\|0);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 83 | `              const pf   = n(s.points_for);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 84 | `              const pa   = n(s.points_against);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 85 | `              const diff = pf - pa;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 86 | `              const winp = gp ? Math.round((Number(s.wins\|\|0) / gp) * 100) + '%' : '-';` | แท็ก/ข้อความ HTML อื่น ๆ |
| 87 | `              return `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 88 | `                <tr>` | ตารางข้อมูล |
| 89 | `                  <td>${i + 1}</td>` | ตารางข้อมูล |
| 90 | `                  <td>${s.name}</td>` | ตารางข้อมูล |
| 91 | `                  <td>${gp}</td>` | ตารางข้อมูล |
| 92 | `                  <td>${n(s.wins)}</td>` | ตารางข้อมูล |
| 93 | `                  <td>${n(s.losses)}</td>` | ตารางข้อมูล |
| 94 | `                  <td>${pf}</td>` | ตารางข้อมูล |
| 95 | `                  <td>${pa}</td>` | ตารางข้อมูล |
| 96 | `                  <td>${diff >= 0 ? "+" : ""}${diff}</td>` | ตารางข้อมูล |
| 97 | `                  <td>${winp}</td>` | ตารางข้อมูล |
| 98 | `                </tr>`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 99 | `            }).join("") \|\| `<tr><td colspan="9"><em>No standings</em></td></tr>`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 100 | `        } catch (e) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 101 | `          document.getElementById("standingsBody").innerHTML =` | แท็ก/ข้อความ HTML อื่น ๆ |
| 102 | `            `<tr><td colspan="9" style="color:#c33">${e.message}</td></tr>`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 103 | `          if (String(e.message).includes("401")) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 104 | `            // token หมดอายุ → เด้งไป login เพื่อความเนียน` | แท็ก/ข้อความ HTML อื่น ๆ |
| 105 | `            localStorage.removeItem("token");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 106 | `            location.href = "login.html";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 107 | `          }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 108 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 109 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 110 | `    </script>` | ปิดสคริปต์ |
| 111 | `  </body>` | ปิด body |
| 112 | `</html>` | ปิดเอกสาร HTML |
