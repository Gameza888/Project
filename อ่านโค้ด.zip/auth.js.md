# auth.js — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `const express = require('express');` | นำเข้าโมดูลด้วย CommonJS (`require`) แล้วเก็บในตัวแปร `const` |
| 2 | `const jwt = require('jsonwebtoken');` | นำเข้าโมดูลด้วย CommonJS (`require`) แล้วเก็บในตัวแปร `const` |
| 3 | `const { verifyUser } = require('../services/fileAuth');` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 4 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 5 | `const router = express.Router();` | สร้าง Router ของ Express เพื่อประกาศเส้นทาง (routes) แยกไฟล์ |
| 6 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 7 | `router.post('/login', async (req, res) => {` | ประกาศเส้นทาง HTTP ของ Express ตามเมธอดและพาธ |
| 8 | `  const { username, password } = req.body \|\| {};` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 9 | `  const user = await verifyUser(username, password);` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 10 | `  if (!user) return res.status(401).json({ error: 'Invalid credentials' });` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 11 | `  const token = jwt.sign(` | เกี่ยวข้องกับ JSON Web Token (JWT) |
| 12 | `    { sub: user.username, roles: user.roles, groups: user.groups },` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 13 | `    process.env.JWT_SECRET,` | เกี่ยวข้องกับ JSON Web Token (JWT) |
| 14 | `    { expiresIn: '8h' }` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 15 | `  );` | ปิดบล็อก/ปิดคำสั่ง |
| 16 | `  res.json({ token });` | ส่งข้อมูลกลับเป็น JSON ให้ client |
| 17 | `});` | ปิดบล็อก/ปิดคำสั่ง |
| 18 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 19 | `module.exports = router;` | ส่งออกค่าจากไฟล์ (CommonJS) ให้ไฟล์อื่น `require` ไปใช้ |
