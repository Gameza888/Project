# ticket.html — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `<!DOCTYPE html>` | ประกาศชนิดเอกสาร HTML5 |
| 2 | `<html lang="th">` | แท็ก `<html>` ครอบทั้งเอกสาร และกำหนดภาษา |
| 3 | `  <head>` | หัวเอกสาร: meta, title, link, script ที่ไม่แสดงตรงๆ |
| 4 | `    <meta charset="utf-8" />` | กำหนดเมตาดาต้า (เช่น charset) |
| 5 | `    <title>My Tickets — Basketball Hub</title>` | กำหนดชื่อหน้า (แสดงบนแท็บเบราว์เซอร์) |
| 6 | `    <link rel="stylesheet" href="css/style.css" />` | ลิงก์ไฟล์ภายนอก (เช่น CSS) |
| 7 | `    <style>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 8 | `      .muted {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 9 | `        color: #666;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 10 | `        font-size: 12px;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 11 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 12 | `      .card {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 13 | `        border: 1px solid #ddd;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 14 | `        border-radius: 10px;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 15 | `        padding: 12px;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 16 | `        margin: 10px 0;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 17 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 18 | `      .box {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 19 | `        border: 1px solid #e6e6e6;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 20 | `        border-radius: 8px;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 21 | `        padding: 8px;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 22 | `        margin: 8px 0;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 23 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 24 | `      .row {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 25 | `        display: flex;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 26 | `        gap: 8px;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 27 | `        align-items: center;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 28 | `        margin: 6px 0;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 29 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 30 | `      .pill {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 31 | `        padding: 2px 8px;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 32 | `        border-radius: 12px;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 33 | `        background: #eee;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 34 | `        font-size: 12px;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 35 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 36 | `      nav {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 37 | `        display: flex;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 38 | `        gap: 12px;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 39 | `        align-items: center;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 40 | `        margin-bottom: 16px;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 41 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 42 | `      button[disabled] {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 43 | `        opacity: 0.5;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 44 | `        cursor: not-allowed;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 45 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 46 | `    </style>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 47 | `  </head>` | ปิดส่วน head |
| 48 | `  <body>` | ส่วนเนื้อหาเพจที่จะมองเห็น |
| 49 | `    <div id="nav"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 50 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 51 | `    <div class="card">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 52 | `      <div class="row">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 53 | `        <label for="eventId"><strong>Event ID:</strong></label>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 54 | `        <input id="eventId" value="11" size="6" />` | ช่องกรอกข้อมูลในฟอร์ม |
| 55 | `        <button id="searchBtn">Search</button>` | ปุ่มกด |
| 56 | `      </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 57 | `      <div id="eventInfo" class="muted"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 58 | `    </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 59 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 60 | `    <div class="card">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 61 | `      <h3>My Orders for this Event</h3>` | หัวข้อข้อความ |
| 62 | `      <div id="myOrders"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 63 | `    </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 64 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 65 | `    <div class="card">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 66 | `      <h3>My Tickets (Paid)</h3>` | หัวข้อข้อความ |
| 67 | `      <div id="paidTickets"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 68 | `    </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 69 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 70 | `    <script src="_common.js"></script>` | ฝัง/ลิงก์สคริปต์ JavaScript |
| 71 | `    <script>` | ฝัง/ลิงก์สคริปต์ JavaScript |
| 72 | `      // ---------- small helpers ----------` | แท็ก/ข้อความ HTML อื่น ๆ |
| 73 | `      function n2(x) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 74 | `        return Number(x \|\| 0);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 75 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 76 | `      function money(x) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 77 | `        return n2(x).toFixed(2);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 78 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 79 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 80 | `      // ใส่ Nav + สถานะผู้ใช้` | แท็ก/ข้อความ HTML อื่น ๆ |
| 81 | `      document.getElementById("nav").innerHTML = navBar("mytickets");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 82 | `      bindLogout();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 83 | `      if (!me()) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 84 | `        // ต้องล็อกอินก่อนใช้งาน` | แท็ก/ข้อความ HTML อื่น ๆ |
| 85 | `        alert("ต้องเข้าสู่ระบบก่อนใช้งาน My Tickets");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 86 | `        location.href = "login.html";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 87 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 88 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 89 | `      // ---------- UI refs ----------` | แท็ก/ข้อความ HTML อื่น ๆ |
| 90 | `      const eventInfo = document.getElementById("eventInfo");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 91 | `      const myOrdersBox = document.getElementById("myOrders");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 92 | `      const paidBox = document.getElementById("paidTickets");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 93 | `      const eventInput = document.getElementById("eventId");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 94 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 95 | `      // ---------- data loaders ----------` | แท็ก/ข้อความ HTML อื่น ๆ |
| 96 | `      async function loadEventInfoById(eventId) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 97 | `        const e = await fetchJSON(`/api/events/${eventId}`);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 98 | `        if (!e) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 99 | `          eventInfo.textContent = "No event found";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 100 | `          return null;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 101 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 102 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 103 | `        // พยายามเรียก matches/:id ถ้า backend ไม่มีให้ fallback เป็น /matches แล้ว find` | แท็ก/ข้อความ HTML อื่น ๆ |
| 104 | `        let m = null;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 105 | `        try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 106 | `          m = await fetchJSON(`/api/matches/${e.match_id}`);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 107 | `        } catch {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 108 | `          const all = await fetchJSON(`/api/matches`);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 109 | `          m = all.find((x) => x.id === e.match_id);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 110 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 111 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 112 | `        eventInfo.innerHTML =` | แท็ก/ข้อความ HTML อื่น ๆ |
| 113 | `          `Event #${e.id} for Match #${e.match_id} — ` +` | แท็ก/ข้อความ HTML อื่น ๆ |
| 114 | `          (m` | แท็ก/ข้อความ HTML อื่น ๆ |
| 115 | `            ? `${m.home_name} vs ${m.away_name} @ ${m.venue \|\| "-"} (${new Date(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 116 | `                m.tipoff_at` | แท็ก/ข้อความ HTML อื่น ๆ |
| 117 | `              ).toLocaleString()})`` | แท็ก/ข้อความ HTML อื่น ๆ |
| 118 | `            : "") +` | แท็ก/ข้อความ HTML อื่น ๆ |
| 119 | `          `<br>Sales: ${` | แท็ก/ข้อความ HTML อื่น ๆ |
| 120 | `            e.sales_open_at ? new Date(e.sales_open_at).toLocaleString() : "-"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 121 | `          } → ${` | แท็ก/ข้อความ HTML อื่น ๆ |
| 122 | `            e.sales_close_at ? new Date(e.sales_close_at).toLocaleString() : "-"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 123 | `          }`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 124 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 125 | `        return e;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 126 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 127 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 128 | `      async function loadMyOrdersForEvent(eventId) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 129 | `        myOrdersBox.innerHTML = "Loading...";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 130 | `        try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 131 | `          const data = await fetchJSON(`/api/my/orders?eventId=${eventId}`, {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 132 | `            headers: { ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 133 | `          });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 134 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 135 | `          // โชว์เฉพาะ pending เท่านั้น` | แท็ก/ข้อความ HTML อื่น ๆ |
| 136 | `          const rows = (data \|\| []).filter((g) => g.order.status === "pending");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 137 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 138 | `          myOrdersBox.innerHTML =` | แท็ก/ข้อความ HTML อื่น ๆ |
| 139 | `            rows` | แท็ก/ข้อความ HTML อื่น ๆ |
| 140 | `              .map(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 141 | `                (g) => `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 142 | `        <div class="box">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 143 | `          <div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 144 | `            <strong>Order #${g.order.id}</strong> —` | แท็ก/ข้อความ HTML อื่น ๆ |
| 145 | `            total: ${Number(g.order.total \|\| 0).toFixed(2)} —` | แท็ก/ข้อความ HTML อื่น ๆ |
| 146 | `            status: ${g.order.status} —` | แท็ก/ข้อความ HTML อื่น ๆ |
| 147 | `            created: ${new Date(g.order.created_at).toLocaleString()}` | แท็ก/ข้อความ HTML อื่น ๆ |
| 148 | `          </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 149 | `          <div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 150 | `            Items: ${` | แท็ก/ข้อความ HTML อื่น ๆ |
| 151 | `              (g.items \|\| [])` | แท็ก/ข้อความ HTML อื่น ๆ |
| 152 | `                .map(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 153 | `                  (i) =>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 154 | `                    `${i.section}-${i.row_label}-${i.seat_number} (${Number(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 155 | `                      i.price \|\| 0` | แท็ก/ข้อความ HTML อื่น ๆ |
| 156 | `                    ).toFixed(2)})`` | แท็ก/ข้อความ HTML อื่น ๆ |
| 157 | `                )` | แท็ก/ข้อความ HTML อื่น ๆ |
| 158 | `                .join(", ") \|\| "-"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 159 | `            }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 160 | `          </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 161 | `          <div style="margin-top:6px">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 162 | `            <button data-act="my-pay" data-id="${` | ปุ่มกด |
| 163 | `              g.order.id` | แท็ก/ข้อความ HTML อื่น ๆ |
| 164 | `            }">Mark as Paid</button>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 165 | `            <button data-act="my-cancel" data-id="${` | ปุ่มกด |
| 166 | `              g.order.id` | แท็ก/ข้อความ HTML อื่น ๆ |
| 167 | `            }">Cancel this order</button>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 168 | `          </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 169 | `        </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 170 | `      `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 171 | `              )` | แท็ก/ข้อความ HTML อื่น ๆ |
| 172 | `              .join("") \|\| "<em>No pending orders</em>";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 173 | `        } catch (e) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 174 | `          myOrdersBox.innerHTML = `<span style="color:#d33">${e.message}</span>`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 175 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 176 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 177 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 178 | `      async function loadPaidTickets() {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 179 | `        const rows = await fetchJSON("/api/my/tickets", {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 180 | `          headers: { ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 181 | `        });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 182 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 183 | `        const byOrder = {};` | แท็ก/ข้อความ HTML อื่น ๆ |
| 184 | `        for (const r of rows) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 185 | `          if (!byOrder[r.order_id]) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 186 | `            byOrder[r.order_id] = {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 187 | `              order_id: r.order_id,` | แท็ก/ข้อความ HTML อื่น ๆ |
| 188 | `              tipoff_at: r.tipoff_at,` | แท็ก/ข้อความ HTML อื่น ๆ |
| 189 | `              venue: r.venue,` | แท็ก/ข้อความ HTML อื่น ๆ |
| 190 | `              home_name: r.home_name,` | แท็ก/ข้อความ HTML อื่น ๆ |
| 191 | `              away_name: r.away_name,` | แท็ก/ข้อความ HTML อื่น ๆ |
| 192 | `              items: [],` | แท็ก/ข้อความ HTML อื่น ๆ |
| 193 | `              total: 0,` | แท็ก/ข้อความ HTML อื่น ๆ |
| 194 | `            };` | แท็ก/ข้อความ HTML อื่น ๆ |
| 195 | `          }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 196 | `          byOrder[r.order_id].items.push(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 197 | `            `${r.section}-${r.row_label}-${r.seat_number} (${Number(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 198 | `              r.price` | แท็ก/ข้อความ HTML อื่น ๆ |
| 199 | `            ).toFixed(2)})`` | แท็ก/ข้อความ HTML อื่น ๆ |
| 200 | `          );` | แท็ก/ข้อความ HTML อื่น ๆ |
| 201 | `          byOrder[r.order_id].total += Number(r.price); // << แปลงเป็น Number เสมอ` | แท็ก/ข้อความ HTML อื่น ๆ |
| 202 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 203 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 204 | `        const list = Object.values(byOrder);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 205 | `        const box = document.getElementById("paidTickets"); // << ใช้กล่องนี้` | แท็ก/ข้อความ HTML อื่น ๆ |
| 206 | `        box.innerHTML =` | แท็ก/ข้อความ HTML อื่น ๆ |
| 207 | `          list` | แท็ก/ข้อความ HTML อื่น ๆ |
| 208 | `            .map(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 209 | `              (t) => `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 210 | `      <div class="box">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 211 | `        <div><strong>Order #${t.order_id}</strong> — ${t.home_name} vs ${` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 212 | `                t.away_name` | แท็ก/ข้อความ HTML อื่น ๆ |
| 213 | `              } @ ${t.venue} — ${new Date(t.tipoff_at).toLocaleString()}</div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 214 | `        <div>Seat: ${t.items.join(", ")}</div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 215 | `        <div class="muted">Total: ${t.total.toFixed(2)}</div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 216 | `      </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 217 | `    `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 218 | `            )` | แท็ก/ข้อความ HTML อื่น ๆ |
| 219 | `            .join("") \|\| "<em>No paid tickets</em>";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 220 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 221 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 222 | `      // ---------- actions ----------` | แท็ก/ข้อความ HTML อื่น ๆ |
| 223 | `      async function doSearch() {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 224 | `        const id = Number(eventInput.value);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 225 | `        if (!id) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 226 | `          eventInfo.textContent = "กรอก Event ID ให้ถูกต้อง";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 227 | `          return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 228 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 229 | `        const e = await loadEventInfoById(id);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 230 | `        if (!e) return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 231 | `        await loadMyOrdersForEvent(e.id);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 232 | `        await loadPaidTickets();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 233 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 234 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 235 | `      document.getElementById("searchBtn").onclick = doSearch;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 236 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 237 | `      // delegate ปุ่ม Mark as Paid / Cancel` | แท็ก/ข้อความ HTML อื่น ๆ |
| 238 | `      document.addEventListener("click", async (ev) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 239 | `        const act = ev.target?.dataset?.act;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 240 | `        if (!act) return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 241 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 242 | `        const orderId = Number(ev.target.dataset.id);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 243 | `        if (!orderId) return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 244 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 245 | `        if (act === "my-pay") {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 246 | `          try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 247 | `            await fetchJSON(`/api/my/orders/${orderId}/pay`, {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 248 | `              method: "POST",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 249 | `              headers: { ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 250 | `            });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 251 | `            // เอากล่องของออร์เดอร์นี้ออกทันที` | แท็ก/ข้อความ HTML อื่น ๆ |
| 252 | `            ev.target.closest(".box")?.remove();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 253 | `            // รีเฟรชตั๋วที่จ่ายแล้วให้เห็นใบที่เพิ่งจ่าย` | แท็ก/ข้อความ HTML อื่น ๆ |
| 254 | `            await loadPaidTickets();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 255 | `          } catch (e) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 256 | `            alert(e.message);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 257 | `          }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 258 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 259 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 260 | `        if (act === "my-cancel") {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 261 | `          if (!confirm(`Cancel order #${orderId}?`)) return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 262 | `          try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 263 | `            await fetchJSON(`/api/my/orders/${orderId}/cancel`, {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 264 | `              method: "POST",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 265 | `              headers: { ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 266 | `            });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 267 | `            ev.target.closest(".box")?.remove();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 268 | `            // ยกเลิกแล้วไม่ต้องไปเพิ่มที่ Paid ก็พอ` | แท็ก/ข้อความ HTML อื่น ๆ |
| 269 | `          } catch (e) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 270 | `            alert(e.message);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 271 | `          }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 272 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 273 | `      });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 274 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 275 | `      // ---------- initial ----------` | แท็ก/ข้อความ HTML อื่น ๆ |
| 276 | `      doSearch(); // โหลดทันทีด้วยค่าเริ่มต้นในช่อง Event ID` | แท็ก/ข้อความ HTML อื่น ๆ |
| 277 | `    </script>` | ปิดสคริปต์ |
| 278 | `  </body>` | ปิด body |
| 279 | `</html>` | ปิดเอกสาร HTML |
