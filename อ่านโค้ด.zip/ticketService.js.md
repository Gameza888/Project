# ticketService.js — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `// services/ticketService.js` | คอมเมนต์อธิบายโค้ด |
| 2 | `const pool = require('../db');` | นำเข้าโมดูลด้วย CommonJS (`require`) แล้วเก็บในตัวแปร `const` |
| 3 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 4 | `async function createOrderWithSeats(eventId, userRef, seatIds = []) {` | ประกาศฟังก์ชันแบบ async รองรับ await |
| 5 | `  if (!Array.isArray(seatIds) \|\| seatIds.length === 0) {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 6 | `    throw new Error('No seats selected');` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 7 | `  }` | ปิดบล็อก/ปิดคำสั่ง |
| 8 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 9 | `  const client = await pool.connect();` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 10 | `  try {` | เริ่มบล็อก try เพื่อดักจับข้อผิดพลาด |
| 11 | `    await client.query('BEGIN');` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 12 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 13 | `    // 1) ตรวจว่า event มีจริง และ (ถ้าต้องการ) อยู่ในช่วงเวลาขาย` | คอมเมนต์อธิบายโค้ด |
| 14 | `    const { rows: ev } = await client.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 15 | `      `SELECT id, sales_open_at, sales_close_at` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 16 | `         FROM event WHERE id=$1 FOR UPDATE`,` | ล็อกแถวในตารางขณะทรานแซกชัน (กันชนกัน) |
| 17 | `      [Number(eventId)]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 18 | `    );` | ปิดบล็อก/ปิดคำสั่ง |
| 19 | `    if (!ev[0]) throw new Error('Event not found');` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 20 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 21 | `    // ถ้าอยากบังคับช่วงเวลา เปิดคอมเมนต์ 3 บรรทัดด้านล่าง` | คอมเมนต์อธิบายโค้ด |
| 22 | `    // const now = new Date();` | คอมเมนต์อธิบายโค้ด |
| 23 | `    // if (ev[0].sales_open_at && now < ev[0].sales_open_at) throw new Error('Sales not started');` | คอมเมนต์อธิบายโค้ด |
| 24 | `    // if (ev[0].sales_close_at && now > ev[0].sales_close_at) throw new Error('Sales closed');` | คอมเมนต์อธิบายโค้ด |
| 25 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 26 | `    // 2) ล็อกที่นั่งทั้งหมดของ event นั้น (แบบ all-or-nothing ด้วย NOWAIT จะเด้งเร็วถ้ามีคนจองชน)` | คอมเมนต์อธิบายโค้ด |
| 27 | `    const ids = seatIds.map(Number);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 28 | `    const { rows: seats } = await client.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 29 | `      `SELECT * FROM seats` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 30 | `        WHERE id = ANY($1::int[])` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 31 | `          AND event_id = $2` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 32 | `        FOR UPDATE NOWAIT`,` | ล็อกแถวในตารางขณะทรานแซกชัน (กันชนกัน) |
| 33 | `      [ids, Number(eventId)]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 34 | `    );` | ปิดบล็อก/ปิดคำสั่ง |
| 35 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 36 | `    if (seats.length !== ids.length) {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 37 | `      throw new Error('Seats not found for this event');` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 38 | `    }` | ปิดบล็อก/ปิดคำสั่ง |
| 39 | `    if (seats.some(s => s.status !== 'available')) {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 40 | `      throw new Error('Some seats already sold');` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 41 | `    }` | ปิดบล็อก/ปิดคำสั่ง |
| 42 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 43 | `    // 3) สร้างออเดอร์ + รายการที่นั่ง` | คอมเมนต์อธิบายโค้ด |
| 44 | `    const total = seats.reduce((sum, s) => sum + Number(s.price), 0);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 45 | `    const { rows: ord } = await client.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 46 | `      `INSERT INTO orders(user_ref, event_id, total, status)` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 47 | `       VALUES ($1, $2, $3, 'pending')` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 48 | `       RETURNING *`,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 49 | `      [String(userRef), Number(eventId), total]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 50 | `    );` | ปิดบล็อก/ปิดคำสั่ง |
| 51 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 52 | `    // แทรก items และอัปเดตสถานะเก้าอี้` | คอมเมนต์อธิบายโค้ด |
| 53 | `    const orderId = ord[0].id;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 54 | `    for (const s of seats) {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 55 | `      await client.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 56 | `        `INSERT INTO order_items(order_id, seat_id, price)` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 57 | `         VALUES ($1, $2, $3)`,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 58 | `        [orderId, s.id, s.price]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 59 | `      );` | ปิดบล็อก/ปิดคำสั่ง |
| 60 | `      await client.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 61 | `        `UPDATE seats SET status = 'sold' WHERE id = $1`,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 62 | `        [s.id]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 63 | `      );` | ปิดบล็อก/ปิดคำสั่ง |
| 64 | `    }` | ปิดบล็อก/ปิดคำสั่ง |
| 65 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 66 | `    await client.query('COMMIT');` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 67 | `    return ord[0]; // { id, user_ref, event_id, total, ... }` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 68 | `  } catch (e) {` | จับข้อผิดพลาด (exception) ที่เกิดในบล็อก try |
| 69 | `    await client.query('ROLLBACK');` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 70 | `    // ถ้าเป็น error จาก NOWAIT (ที่นั่งโดนล็อกโดยทรานแซกชันอื่น)` | คอมเมนต์อธิบายโค้ด |
| 71 | `    if (String(e.message).includes('could not obtain lock')) {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 72 | `      throw new Error('Seats are being purchased by someone else. Please try again.');` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 73 | `    }` | ปิดบล็อก/ปิดคำสั่ง |
| 74 | `    throw e;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 75 | `  } finally {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 76 | `    client.release();` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 77 | `  }` | ปิดบล็อก/ปิดคำสั่ง |
| 78 | `}` | ปิดบล็อก/ปิดคำสั่ง |
| 79 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 80 | `module.exports = { createOrderWithSeats };` | ส่งออกค่าจากไฟล์ (CommonJS) ให้ไฟล์อื่น `require` ไปใช้ |
