# teams.html — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `<!DOCTYPE html>` | ประกาศชนิดเอกสาร HTML5 |
| 2 | `<html lang="th">` | แท็ก `<html>` ครอบทั้งเอกสาร และกำหนดภาษา |
| 3 | `  <head>` | หัวเอกสาร: meta, title, link, script ที่ไม่แสดงตรงๆ |
| 4 | `    <meta charset="utf-8" />` | กำหนดเมตาดาต้า (เช่น charset) |
| 5 | `    <title>Teams</title>` | กำหนดชื่อหน้า (แสดงบนแท็บเบราว์เซอร์) |
| 6 | `    <link rel="stylesheet" href="css/style.css" />` | ลิงก์ไฟล์ภายนอก (เช่น CSS) |
| 7 | `  </head>` | ปิดส่วน head |
| 8 | `  <body>` | ส่วนเนื้อหาเพจที่จะมองเห็น |
| 9 | `    <div id="nav"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 10 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 11 | `    <section>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 12 | `      <h2>Teams</h2>` | หัวข้อข้อความ |
| 13 | `      <ul id="list"></ul>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 14 | `    </section>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 15 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 16 | `    <section id="admin" style="display: none">` | แท็ก/ข้อความ HTML อื่น ๆ |
| 17 | `      <h3>+ Create team (admin)</h3>` | หัวข้อข้อความ |
| 18 | `      <form id="create">` | ฟอร์มส่งข้อมูล |
| 19 | `        <input name="name" placeholder="Team name" required />` | ช่องกรอกข้อมูลในฟอร์ม |
| 20 | `        <input name="city" placeholder="City" />` | ช่องกรอกข้อมูลในฟอร์ม |
| 21 | `        <input name="short_code" placeholder="Code e.g. LAL" required />` | ช่องกรอกข้อมูลในฟอร์ม |
| 22 | `        <button>Create</button>` | ปุ่มกด |
| 23 | `      </form>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 24 | `      <div id="msg" style="color: #0a0"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 25 | `    </section>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 26 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 27 | `    <script src="_common.js"></script>` | ฝัง/ลิงก์สคริปต์ JavaScript |
| 28 | `    <script>` | ฝัง/ลิงก์สคริปต์ JavaScript |
| 29 | `      document.getElementById("nav").innerHTML = navBar("teams"); // หรือ matches/events/standings ตามหน้า` | แท็ก/ข้อความ HTML อื่น ๆ |
| 30 | `      bindLogout();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 31 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 32 | `      // Gate for guests` | แท็ก/ข้อความ HTML อื่น ๆ |
| 33 | `      if (!me()) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 34 | `        // ซ่อนคอนเทนต์ทั้งหมดของเพจ (ยกเว้น nav และ H1)` | แท็ก/ข้อความ HTML อื่น ๆ |
| 35 | `        [...document.body.children].forEach((el) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 36 | `          if (el.id === "nav") return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 37 | `          if (el.tagName === "H1") return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 38 | `          el.style.display = "none";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 39 | `        });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 40 | `        // แปะข้อความเตือนใต้หัวข้อ` | แท็ก/ข้อความ HTML อื่น ๆ |
| 41 | `        (document.querySelector("h1") \|\| document.body).insertAdjacentHTML(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 42 | `          "beforeend",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 43 | `          `<div class="guest-message">ต้องเข้าสู่ระบบก่อนเพื่อดูข้อมูล</div>`` | แท็ก/ข้อความ HTML อื่น ๆ |
| 44 | `        );` | แท็ก/ข้อความ HTML อื่น ๆ |
| 45 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 46 | `        // กันสคริปต์ส่วนถัดไปของหน้านี้ไม่ให้รันต่อ` | แท็ก/ข้อความ HTML อื่น ๆ |
| 47 | `        throw new Error("GUEST_BLOCKED_TEAMS");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 48 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 49 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 50 | `      (async function load() {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 51 | `        const rows = await (await fetch("/api/teams")).json();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 52 | `        document.getElementById("list").innerHTML = rows` | แท็ก/ข้อความ HTML อื่น ๆ |
| 53 | `          .map((t) => `<li>${t.name} (${t.short_code}) — ${t.city \|\| "-"}</li>`)` | แท็ก/ข้อความ HTML อื่น ๆ |
| 54 | `          .join("");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 55 | `      })();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 56 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 57 | `      if (isAdmin()) document.getElementById("admin").style.display = "block";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 58 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 59 | `      document.getElementById("create").onsubmit = async (e) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 60 | `        e.preventDefault();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 61 | `        const body = Object.fromEntries(new FormData(e.target));` | แท็ก/ข้อความ HTML อื่น ๆ |
| 62 | `        const r = await fetch("/api/teams", {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 63 | `          method: "POST",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 64 | `          headers: { "Content-Type": "application/json", ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 65 | `          body: JSON.stringify(body),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 66 | `        });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 67 | `        const d = await r.json();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 68 | `        if (!r.ok) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 69 | `          alert(d.error \|\| "create failed");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 70 | `          return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 71 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 72 | `        document.getElementById("msg").textContent = "Created: " + d.name;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 73 | `        e.target.reset();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 74 | `        location.reload();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 75 | `      };` | แท็ก/ข้อความ HTML อื่น ๆ |
| 76 | `    </script>` | ปิดสคริปต์ |
| 77 | `  </body>` | ปิด body |
| 78 | `</html>` | ปิดเอกสาร HTML |
