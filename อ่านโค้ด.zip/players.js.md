# players.js — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `// Public/js/players.js` | คอมเมนต์อธิบายโค้ด |
| 2 | `const { requireAuth } = require('../middleware/auth');` | มิดเดิลแวร์บังคับยืนยันตัวตน |
| 3 | `const { hasRole } = require('../middleware/rbac');` | มิดเดิลแวร์ตรวจสิทธิ์บทบาท (RBAC) |
| 4 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 5 | `// ... (GET เดิมคงไว้)` | คอมเมนต์อธิบายโค้ด |
| 6 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 7 | `router.post('/', requireAuth, hasRole('admin'), async (req, res) => {` | ประกาศเส้นทาง HTTP ของ Express ตามเมธอดและพาธ |
| 8 | `  const { team_id, first_name, last_name, position, jersey_number } = req.body;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 9 | `  try {` | เริ่มบล็อก try เพื่อดักจับข้อผิดพลาด |
| 10 | `    const { rows } = await pool.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 11 | `      `INSERT INTO players(team_id, first_name, last_name, position, jersey_number)` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 12 | `       VALUES ($1,$2,$3,$4,$5) RETURNING *`,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 13 | `      [team_id, first_name, last_name, position, jersey_number]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 14 | `    );` | ปิดบล็อก/ปิดคำสั่ง |
| 15 | `    res.status(201).json(rows[0]);` | กำหนดรหัสสถานะ HTTP ก่อนส่งคำตอบ |
| 16 | `  } catch (e) {` | จับข้อผิดพลาด (exception) ที่เกิดในบล็อก try |
| 17 | `    res.status(400).json({ error: e.message });` | กำหนดรหัสสถานะ HTTP ก่อนส่งคำตอบ |
| 18 | `  }` | ปิดบล็อก/ปิดคำสั่ง |
| 19 | `});` | ปิดบล็อก/ปิดคำสั่ง |
