# events.js — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `// Public/js/Events.js` | คอมเมนต์อธิบายโค้ด |
| 2 | `// === Admin: list orders of an event (with items) ===` | คอมเมนต์อธิบายโค้ด |
| 3 | `router.get('/events/:eventId/orders', requireAuth, hasRole('admin'), async (req, res) => {` | ประกาศเส้นทาง HTTP ของ Express ตามเมธอดและพาธ |
| 4 | `  const { rows: orders } = await pool.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 5 | `    `SELECT * FROM orders WHERE event_id=$1 ORDER BY id DESC`,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 6 | `    [req.params.eventId]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 7 | `  );` | ปิดบล็อก/ปิดคำสั่ง |
| 8 | `  const orderIds = orders.map(o => o.id);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 9 | `  const { rows: items } = orderIds.length` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 10 | `    ? await pool.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 11 | `        `SELECT oi.*, s.section, s.row_label, s.seat_number` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 12 | `         FROM order_items oi JOIN seats s ON s.id=oi.seat_id` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 13 | `         WHERE oi.order_id = ANY($1) ORDER BY order_id, seat_id`,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 14 | `        [orderIds]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 15 | `      )` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 16 | `    : { rows: [] };` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 17 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 18 | `  const grouped = orders.map(o => ({` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 19 | `    order: o,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 20 | `    items: items.filter(i => i.order_id === o.id)` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 21 | `  }));` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 22 | `  res.json(grouped);` | ส่งข้อมูลกลับเป็น JSON ให้ client |
| 23 | `});` | ปิดบล็อก/ปิดคำสั่ง |
| 24 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 25 | `// === Admin: cancel whole order (release all seats) ===` | คอมเมนต์อธิบายโค้ด |
| 26 | `router.post('/orders/:orderId/cancel', requireAuth, hasRole('admin'), async (req, res) => {` | ประกาศเส้นทาง HTTP ของ Express ตามเมธอดและพาธ |
| 27 | `  const client = await pool.connect();` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 28 | `  try {` | เริ่มบล็อก try เพื่อดักจับข้อผิดพลาด |
| 29 | `    await client.query('BEGIN');` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 30 | `    const { rows: items } = await client.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 31 | `      `SELECT seat_id FROM order_items WHERE order_id=$1 FOR UPDATE`,` | ล็อกแถวในตารางขณะทรานแซกชัน (กันชนกัน) |
| 32 | `      [req.params.orderId]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 33 | `    );` | ปิดบล็อก/ปิดคำสั่ง |
| 34 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 35 | `    const seatIds = items.map(i => i.seat_id);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 36 | `    if (seatIds.length) {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 37 | `      await client.query(`UPDATE seats SET status='available' WHERE id = ANY($1)`, [seatIds]);` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 38 | `      await client.query(`DELETE FROM order_items WHERE order_id=$1`, [req.params.orderId]);` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 39 | `    }` | ปิดบล็อก/ปิดคำสั่ง |
| 40 | `    await client.query(`UPDATE orders SET status='canceled', total=0 WHERE id=$1`, [req.params.orderId]);` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 41 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 42 | `    await client.query('COMMIT');` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 43 | `    res.json({ ok: true, released: seatIds.length });` | ส่งข้อมูลกลับเป็น JSON ให้ client |
| 44 | `  } catch (e) {` | จับข้อผิดพลาด (exception) ที่เกิดในบล็อก try |
| 45 | `    await client.query('ROLLBACK');` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 46 | `    res.status(400).json({ error: e.message });` | กำหนดรหัสสถานะ HTTP ก่อนส่งคำตอบ |
| 47 | `  } finally {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 48 | `    client.release();` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 49 | `  }` | ปิดบล็อก/ปิดคำสั่ง |
| 50 | `});` | ปิดบล็อก/ปิดคำสั่ง |
| 51 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 52 | `// === Admin: release a single seat from an order ===` | คอมเมนต์อธิบายโค้ด |
| 53 | `router.post('/orders/:orderId/release-seat', requireAuth, hasRole('admin'), async (req, res) => {` | ประกาศเส้นทาง HTTP ของ Express ตามเมธอดและพาธ |
| 54 | `  const { seat_id } = req.body;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 55 | `  const client = await pool.connect();` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 56 | `  try {` | เริ่มบล็อก try เพื่อดักจับข้อผิดพลาด |
| 57 | `    await client.query('BEGIN');` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 58 | `    await client.query(`DELETE FROM order_items WHERE order_id=$1 AND seat_id=$2`, [req.params.orderId, seat_id]);` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 59 | `    await client.query(`UPDATE seats SET status='available' WHERE id=$1`, [seat_id]);` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 60 | `    await client.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 61 | `      `UPDATE orders o` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 62 | `       SET total = COALESCE((SELECT SUM(price) FROM order_items WHERE order_id=o.id), 0)` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 63 | `       WHERE id=$1`, [req.params.orderId]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 64 | `    );` | ปิดบล็อก/ปิดคำสั่ง |
| 65 | `    await client.query('COMMIT');` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 66 | `    res.json({ ok: true });` | ส่งข้อมูลกลับเป็น JSON ให้ client |
| 67 | `  } catch (e) {` | จับข้อผิดพลาด (exception) ที่เกิดในบล็อก try |
| 68 | `    await client.query('ROLLBACK');` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 69 | `    res.status(400).json({ error: e.message });` | กำหนดรหัสสถานะ HTTP ก่อนส่งคำตอบ |
| 70 | `  } finally {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 71 | `    client.release();` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 72 | `  }` | ปิดบล็อก/ปิดคำสั่ง |
| 73 | `});` | ปิดบล็อก/ปิดคำสั่ง |
