# login.html — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `<!DOCTYPE html>` | ประกาศชนิดเอกสาร HTML5 |
| 2 | `<html lang="th">` | แท็ก `<html>` ครอบทั้งเอกสาร และกำหนดภาษา |
| 3 | `  <head>` | หัวเอกสาร: meta, title, link, script ที่ไม่แสดงตรงๆ |
| 4 | `    <meta charset="utf-8" />` | กำหนดเมตาดาต้า (เช่น charset) |
| 5 | `    <title>Login</title>` | กำหนดชื่อหน้า (แสดงบนแท็บเบราว์เซอร์) |
| 6 | `    <link rel="stylesheet" href="css/style.css" />` | ลิงก์ไฟล์ภายนอก (เช่น CSS) |
| 7 | `  </head>` | ปิดส่วน head |
| 8 | `  <body>` | ส่วนเนื้อหาเพจที่จะมองเห็น |
| 9 | `    <div id="nav"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 10 | `    <div` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 11 | `      style="` | แท็ก/ข้อความ HTML อื่น ๆ |
| 12 | `        max-width: 360px;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 13 | `        margin: 24px auto;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 14 | `        border: 1px solid #ddd;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 15 | `        border-radius: 10px;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 16 | `        padding: 16px;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 17 | `      "` | แท็ก/ข้อความ HTML อื่น ๆ |
| 18 | `    >` | แท็ก/ข้อความ HTML อื่น ๆ |
| 19 | `      <h2>Login</h2>` | หัวข้อข้อความ |
| 20 | `      <form id="f">` | ฟอร์มส่งข้อมูล |
| 21 | `        <input` | ช่องกรอกข้อมูลในฟอร์ม |
| 22 | `          name="username"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 23 | `          placeholder="username"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 24 | `          required` | แท็ก/ข้อความ HTML อื่น ๆ |
| 25 | `          style="width: 100%; margin: 6px 0"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 26 | `        />` | แท็ก/ข้อความ HTML อื่น ๆ |
| 27 | `        <input` | ช่องกรอกข้อมูลในฟอร์ม |
| 28 | `          name="password"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 29 | `          type="password"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 30 | `          placeholder="password"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 31 | `          required` | แท็ก/ข้อความ HTML อื่น ๆ |
| 32 | `          style="width: 100%; margin: 6px 0"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 33 | `        />` | แท็ก/ข้อความ HTML อื่น ๆ |
| 34 | `        <button style="width: 100%">Sign in</button>` | ปุ่มกด |
| 35 | `        <div id="msg" style="color: #d33; margin-top: 8px"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 36 | `      </form>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 37 | `    </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 38 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 39 | `    <script src="_common.js"></script>` | ฝัง/ลิงก์สคริปต์ JavaScript |
| 40 | `    <script>` | ฝัง/ลิงก์สคริปต์ JavaScript |
| 41 | `      document.getElementById("nav").innerHTML = navBar();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 42 | `      bindLogout();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 43 | `      document.getElementById("f").onsubmit = async (e) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 44 | `        e.preventDefault();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 45 | `        const body = Object.fromEntries(new FormData(e.target));` | แท็ก/ข้อความ HTML อื่น ๆ |
| 46 | `        const r = await fetch("/api/auth/login", {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 47 | `          method: "POST",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 48 | `          headers: { "Content-Type": "application/json" },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 49 | `          body: JSON.stringify(body),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 50 | `        });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 51 | `        const d = await r.json();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 52 | `        if (!r.ok) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 53 | `          document.getElementById("msg").textContent =` | แท็ก/ข้อความ HTML อื่น ๆ |
| 54 | `            d.error \|\| "Login failed";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 55 | `          return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 56 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 57 | `        localStorage.setItem("token", d.token);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 58 | `        location.href = "index.html";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 59 | `      };` | แท็ก/ข้อความ HTML อื่น ๆ |
| 60 | `    </script>` | ปิดสคริปต์ |
| 61 | `  </body>` | ปิด body |
| 62 | `</html>` | ปิดเอกสาร HTML |
