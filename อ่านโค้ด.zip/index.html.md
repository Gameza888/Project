# index.html — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `<!doctype html>` | ประกาศชนิดเอกสาร HTML5 |
| 2 | `<html lang="th">` | แท็ก `<html>` ครอบทั้งเอกสาร และกำหนดภาษา |
| 3 | `<head>` | หัวเอกสาร: meta, title, link, script ที่ไม่แสดงตรงๆ |
| 4 | `  <meta charset="utf-8" />` | กำหนดเมตาดาต้า (เช่น charset) |
| 5 | `  <title>Basketball Hub</title>` | กำหนดชื่อหน้า (แสดงบนแท็บเบราว์เซอร์) |
| 6 | `  <link rel="stylesheet" href="css/style.css" />` | ลิงก์ไฟล์ภายนอก (เช่น CSS) |
| 7 | `</head>` | ปิดส่วน head |
| 8 | `<body>` | ส่วนเนื้อหาเพจที่จะมองเห็น |
| 9 | `  <div id="nav"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 10 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 11 | `  <h2>Fixtures</h2>` | หัวข้อข้อความ |
| 12 | `  <div id="fixtures"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 13 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 14 | `  <script src="_common.js"></script>` | ฝัง/ลิงก์สคริปต์ JavaScript |
| 15 | `  <script>` | ฝัง/ลิงก์สคริปต์ JavaScript |
| 16 | `    document.getElementById('nav').innerHTML = navBar('home');` | แท็ก/ข้อความ HTML อื่น ๆ |
| 17 | `    bindLogout();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 18 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 19 | `    (async ()=>{` | แท็ก/ข้อความ HTML อื่น ๆ |
| 20 | `      const fx = await (await fetch('/api/matches')).json();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 21 | `      document.getElementById('fixtures').innerHTML =` | แท็ก/ข้อความ HTML อื่น ๆ |
| 22 | `        fx.map(m => `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 23 | `          <div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 24 | `            ${new Date(m.tipoff_at).toLocaleString()}` | แท็ก/ข้อความ HTML อื่น ๆ |
| 25 | `            — ${m.home_name} vs ${m.away_name}` | แท็ก/ข้อความ HTML อื่น ๆ |
| 26 | `            @ ${m.venue \|\| '-'} [${m.status}] ${m.home_score}:${m.away_score}` | แท็ก/ข้อความ HTML อื่น ๆ |
| 27 | `          </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 28 | `        `).join('') \|\| '<em>No fixtures</em>';` | แท็ก/ข้อความ HTML อื่น ๆ |
| 29 | `    })();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 30 | `  </script>` | ปิดสคริปต์ |
| 31 | `</body>` | ปิด body |
| 32 | `</html>` | ปิดเอกสาร HTML |
