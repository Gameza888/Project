# events.html — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `<!DOCTYPE html>` | ประกาศชนิดเอกสาร HTML5 |
| 2 | `<html lang="th">` | แท็ก `<html>` ครอบทั้งเอกสาร และกำหนดภาษา |
| 3 | `  <head>` | หัวเอกสาร: meta, title, link, script ที่ไม่แสดงตรงๆ |
| 4 | `    <meta charset="utf-8" />` | กำหนดเมตาดาต้า (เช่น charset) |
| 5 | `    <title>Events & Ticketing</title>` | กำหนดชื่อหน้า (แสดงบนแท็บเบราว์เซอร์) |
| 6 | `    <link rel="stylesheet" href="css/style.css" />` | ลิงก์ไฟล์ภายนอก (เช่น CSS) |
| 7 | `    <style>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 8 | `      .row {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 9 | `        display: flex;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 10 | `        gap: 10px;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 11 | `        align-items: center;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 12 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 13 | `      .card {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 14 | `        border: 1px solid #ddd;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 15 | `        border-radius: 10px;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 16 | `        padding: 12px;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 17 | `        margin: 10px 0;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 18 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 19 | `      button[disabled] {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 20 | `        opacity: 0.5;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 21 | `        cursor: not-allowed;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 22 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 23 | `    </style>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 24 | `  </head>` | ปิดส่วน head |
| 25 | `  <body>` | ส่วนเนื้อหาเพจที่จะมองเห็น |
| 26 | `    <div id="nav"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 27 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 28 | `    <section class="card">` | แท็ก/ข้อความ HTML อื่น ๆ |
| 29 | `      <h2>Find Event by Match</h2>` | หัวข้อข้อความ |
| 30 | `      <div class="row">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 31 | `        <input id="matchId" value="1" size="6" />` | ช่องกรอกข้อมูลในฟอร์ม |
| 32 | `        <button id="find">Find</button>` | ปุ่มกด |
| 33 | `      </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 34 | `      <div id="eventInfo" style="margin-top: 8px"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 35 | `    </section>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 36 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 37 | `    <section class="card">` | แท็ก/ข้อความ HTML อื่น ๆ |
| 38 | `      <h3>Seats</h3>` | หัวข้อข้อความ |
| 39 | `      <div id="seats"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 40 | `      <div style="margin-top: 8px">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 41 | `        <button id="buy" disabled>Buy selected</button>` | ปุ่มกด |
| 42 | `        <span id="msg" style="margin-left: 8px"></span>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 43 | `      </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 44 | `    </section>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 45 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 46 | `    <!-- ===== Admin: Orders (log แบบย่อ + limit ใช้ได้) ===== -->` | คอมเมนต์ใน HTML (ไม่แสดงผล) |
| 47 | `    <section id="adminOrdersPane" class="card" style="display: none">` | แท็ก/ข้อความ HTML อื่น ๆ |
| 48 | `      <h3>Admin — Orders of this Event</h3>` | หัวข้อข้อความ |
| 49 | `      <div class="row" style="margin: 6px 0">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 50 | `        <label>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 51 | `          Status:` | แท็ก/ข้อความ HTML อื่น ๆ |
| 52 | `          <select id="adminFilter">` | แท็ก/ข้อความ HTML อื่น ๆ |
| 53 | `            <option value="all">all</option>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 54 | `            <option value="pending">pending</option>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 55 | `            <option value="paid">paid</option>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 56 | `          </select>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 57 | `        </label>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 58 | `        <label><input type="checkbox" id="showCanceled" /> Show canceled</label>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 59 | `        <label> Limit: <input id="adminLimit" value="10" size="4" /></label>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 60 | `        <button id="reloadOrders">Reload</button>` | ปุ่มกด |
| 61 | `      </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 62 | `      <div id="adminOrders"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 63 | `    </section>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 64 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 65 | `    <!-- ===== Admin: tools ===== -->` | คอมเมนต์ใน HTML (ไม่แสดงผล) |
| 66 | `    <section id="adminTools" class="card" style="display: none">` | แท็ก/ข้อความ HTML อื่น ๆ |
| 67 | `      <h3>Admin tools</h3>` | หัวข้อข้อความ |
| 68 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 69 | `      <h4>Create Event</h4>` | หัวข้อข้อความ |
| 70 | `      <form id="createEvent" class="row">` | ฟอร์มส่งข้อมูล |
| 71 | `        <input name="match_id" placeholder="match_id" required />` | ช่องกรอกข้อมูลในฟอร์ม |
| 72 | `        <input name="sales_open_at" type="datetime-local" />` | ช่องกรอกข้อมูลในฟอร์ม |
| 73 | `        <input name="sales_close_at" type="datetime-local" />` | ช่องกรอกข้อมูลในฟอร์ม |
| 74 | `        <button>Create</button>` | ปุ่มกด |
| 75 | `      </form>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 76 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 77 | `      <h4>Bulk add seats to Event</h4>` | หัวข้อข้อความ |
| 78 | `      <form id="addSeats">` | ฟอร์มส่งข้อมูล |
| 79 | `        <input name="eventId" placeholder="eventId" required />` | ช่องกรอกข้อมูลในฟอร์ม |
| 80 | `        <textarea` | แท็ก/ข้อความ HTML อื่น ๆ |
| 81 | `          name="rows"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 82 | `          rows="4"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 83 | `          style="width: 100%; max-width: 720px"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 84 | `          placeholder='หนึ่งบรรทัดต่อหนึ่งที่นั่ง เช่น` | แท็ก/ข้อความ HTML อื่น ๆ |
| 85 | `{"section":"A","row_label":"A","seat_number":1,"price":800}` | แท็ก/ข้อความ HTML อื่น ๆ |
| 86 | `{"section":"A","row_label":"A","seat_number":2,"price":800}'` | แท็ก/ข้อความ HTML อื่น ๆ |
| 87 | `        ></textarea>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 88 | `        <div style="margin-top: 8px">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 89 | `          <button>Add/Update</button>` | ปุ่มกด |
| 90 | `        </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 91 | `      </form>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 92 | `    </section>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 93 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 94 | `    <div id="seedBox" style="margin-top: 8px; display: none">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 95 | `      <button id="seedDefaultSeats" type="button">` | ปุ่มกด |
| 96 | `        Generate default seats (A×10 @800, B×10 @500)` | แท็ก/ข้อความ HTML อื่น ๆ |
| 97 | `      </button>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 98 | `    </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 99 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 100 | `    <!-- ===== User: my orders (เฉพาะ user ปกติ) ===== -->` | คอมเมนต์ใน HTML (ไม่แสดงผล) |
| 101 | `    <section id="my" class="card" style="display: none">` | แท็ก/ข้อความ HTML อื่น ๆ |
| 102 | `      <h3>My Orders for this Event</h3>` | หัวข้อข้อความ |
| 103 | `      <div id="myOrders" style="margin-top: 8px"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 104 | `    </section>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 105 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 106 | `    <script src="_common.js"></script>` | ฝัง/ลิงก์สคริปต์ JavaScript |
| 107 | `    <script>` | ฝัง/ลิงก์สคริปต์ JavaScript |
| 108 | `      /* ===== boot ===== */` | แท็ก/ข้อความ HTML อื่น ๆ |
| 109 | `      document.getElementById("nav").innerHTML = navBar("events");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 110 | `      bindLogout();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 111 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 112 | `      // Gate for guests` | แท็ก/ข้อความ HTML อื่น ๆ |
| 113 | `      if (!me()) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 114 | `        // ซ่อนทุก section ที่เป็นการใช้งาน` | แท็ก/ข้อความ HTML อื่น ๆ |
| 115 | `        document` | แท็ก/ข้อความ HTML อื่น ๆ |
| 116 | `          .querySelectorAll(".card, #adminOrdersPane, #adminTools, #my")` | แท็ก/ข้อความ HTML อื่น ๆ |
| 117 | `          .forEach((el) => (el.style.display = "none"));` | แท็ก/ข้อความ HTML อื่น ๆ |
| 118 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 119 | `        // แสดงข้อความแทน` | แท็ก/ข้อความ HTML อื่น ๆ |
| 120 | `        document.body.insertAdjacentHTML(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 121 | `          "beforeend",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 122 | `          `<div class="guest-message">ต้องเข้าสู่ระบบก่อนเพื่อดูข้อมูล</div>`` | แท็ก/ข้อความ HTML อื่น ๆ |
| 123 | `        );` | แท็ก/ข้อความ HTML อื่น ๆ |
| 124 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 125 | `        // กันการทำงานต่อ เช่น bind ปุ่ม / โหลดที่นั่ง` | แท็ก/ข้อความ HTML อื่น ๆ |
| 126 | `        throw new Error("GUEST_BLOCKED");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 127 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 128 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 129 | `      const amAdmin = isAdmin();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 130 | `      const loggedIn = !!me();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 131 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 132 | `      // แสดงผลตาม role` | แท็ก/ข้อความ HTML อื่น ๆ |
| 133 | `      if (amAdmin) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 134 | `        document.getElementById("my").style.display = "none";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 135 | `        document.getElementById("seedBox").style.display = "block";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 136 | `        document.getElementById("adminOrdersPane").style.display = "block";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 137 | `        document.getElementById("adminTools").style.display = "block";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 138 | `      } else if (loggedIn) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 139 | `        document.getElementById("my").style.display = "block";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 140 | `        document.getElementById("adminOrdersPane").style.display = "none";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 141 | `        document.getElementById("adminTools").style.display = "none";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 142 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 143 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 144 | `      /* ===== helpers ===== */` | แท็ก/ข้อความ HTML อื่น ๆ |
| 145 | `      function n(x) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 146 | `        return Number(x \|\| 0);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 147 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 148 | `      function money(x) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 149 | `        return n(x).toFixed(2);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 150 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 151 | `      function on(id, type, fn) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 152 | `        const el = document.getElementById(id);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 153 | `        if (el) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 154 | `          el.addEventListener(type, fn);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 155 | `          return true;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 156 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 157 | `        return false;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 158 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 159 | `      async function fetchJSON(url, opt = {}) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 160 | `        const r = await fetch(url, opt);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 161 | `        if (!r.ok) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 162 | `          let msg = `HTTP ${r.status}`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 163 | `          try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 164 | `            msg = (await r.json()).error \|\| msg;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 165 | `          } catch {}` | แท็ก/ข้อความ HTML อื่น ๆ |
| 166 | `          const e = new Error(msg);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 167 | `          e.status = r.status;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 168 | `          throw e;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 169 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 170 | `        try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 171 | `          return await r.json();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 172 | `        } catch {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 173 | `          return null;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 174 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 175 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 176 | `      function toISO(dt) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 177 | `        if (!dt) return null;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 178 | `        const d = new Date(dt);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 179 | `        return isNaN(d) ? null : d.toISOString();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 180 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 181 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 182 | `      /* ===== state refs ===== */` | แท็ก/ข้อความ HTML อื่น ๆ |
| 183 | `      const selected = new Set();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 184 | `      const matchInput = document.getElementById("matchId");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 185 | `      const eventInfo = document.getElementById("eventInfo");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 186 | `      const seatsDiv = document.getElementById("seats");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 187 | `      const buyBtn = document.getElementById("buy");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 188 | `      const msgSpan = document.getElementById("msg");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 189 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 190 | `      function renderSelected() {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 191 | `        msgSpan.textContent = selected.size` | แท็ก/ข้อความ HTML อื่น ๆ |
| 192 | `          ? `เลือก ${selected.size} ที่นั่ง`` | แท็ก/ข้อความ HTML อื่น ๆ |
| 193 | `          : "";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 194 | `        buyBtn.disabled = !loggedIn \|\| selected.size === 0;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 195 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 196 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 197 | `      /* ===== main: load by match ===== */` | แท็ก/ข้อความ HTML อื่น ๆ |
| 198 | `      async function loadByMatch() {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 199 | `        eventInfo.textContent = "Loading...";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 200 | `        seatsDiv.innerHTML = "";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 201 | `        selected.clear();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 202 | `        renderSelected();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 203 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 204 | `        const mid = Number(matchInput.value);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 205 | `        if (!mid) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 206 | `          eventInfo.textContent = "กรอก match_id";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 207 | `          return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 208 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 209 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 210 | `        try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 211 | `          // 1) match` | แท็ก/ข้อความ HTML อื่น ๆ |
| 212 | `          let m = null;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 213 | `          try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 214 | `            m = await fetchJSON(`/api/matches/${mid}`); // ถ้ามี route นี้` | แท็ก/ข้อความ HTML อื่น ๆ |
| 215 | `          } catch {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 216 | `            // fallback ไปดึงทั้งหมดแล้ว find` | แท็ก/ข้อความ HTML อื่น ๆ |
| 217 | `            const all = await fetchJSON(`/api/matches`);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 218 | `            m = (all \|\| []).find((x) => Number(x.id) === mid) \|\| null;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 219 | `          }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 220 | `          if (!m) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 221 | `            eventInfo.textContent = "Match not found";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 222 | `            return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 223 | `          }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 224 | `          eventInfo.innerHTML =` | แท็ก/ข้อความ HTML อื่น ๆ |
| 225 | `            `Match #${m.id}: ${new Date(m.tipoff_at).toLocaleString()} — ` +` | แท็ก/ข้อความ HTML อื่น ๆ |
| 226 | `            `${m.home_name} vs ${m.away_name} @ ${m.venue \|\| "-"} [${` | แท็ก/ข้อความ HTML อื่น ๆ |
| 227 | `              m.status` | แท็ก/ข้อความ HTML อื่น ๆ |
| 228 | `            }]`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 229 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 230 | `          // 2) event` | แท็ก/ข้อความ HTML อื่น ๆ |
| 231 | `          const e = await fetchJSON(`/api/events/${mid}`);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 232 | `          if (!e) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 233 | `            if (amAdmin) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 234 | `              const btn = document.createElement("button");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 235 | `              btn.textContent = "Create event for this match";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 236 | `              btn.style.marginLeft = "8px";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 237 | `              btn.onclick = async () => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 238 | `                const now = new Date();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 239 | `                const close = new Date(now.getTime() + 3 * 60 * 60 * 1000);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 240 | `                const created = await fetchJSON("/api/events", {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 241 | `                  method: "POST",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 242 | `                  headers: {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 243 | `                    "Content-Type": "application/json",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 244 | `                    ...authHeaders(),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 245 | `                  },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 246 | `                  body: JSON.stringify({` | แท็ก/ข้อความ HTML อื่น ๆ |
| 247 | `                    match_id: m.id,` | แท็ก/ข้อความ HTML อื่น ๆ |
| 248 | `                    sales_open_at: now.toISOString(),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 249 | `                    sales_close_at: close.toISOString(),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 250 | `                  }),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 251 | `                });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 252 | `                alert("Created/Updated event #" + created.id);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 253 | `                await loadByMatch();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 254 | `              };` | แท็ก/ข้อความ HTML อื่น ๆ |
| 255 | `              eventInfo.appendChild(btn);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 256 | `            }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 257 | `            return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 258 | `          }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 259 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 260 | `          // 3) seats` | แท็ก/ข้อความ HTML อื่น ๆ |
| 261 | `          seatsDiv.dataset.eventId = e.id;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 262 | `          const evIdInput = document.querySelector(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 263 | `            '#addSeats [name="eventId"]'` | แท็ก/ข้อความ HTML อื่น ๆ |
| 264 | `          );` | แท็ก/ข้อความ HTML อื่น ๆ |
| 265 | `          if (evIdInput) evIdInput.value = e.id;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 266 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 267 | `          const seats = await fetchJSON(`/api/events/${e.id}/seats`);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 268 | `          seatsDiv.innerHTML =` | แท็ก/ข้อความ HTML อื่น ๆ |
| 269 | `            seats` | แท็ก/ข้อความ HTML อื่น ๆ |
| 270 | `              .map((s) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 271 | `                const label = `${s.section}-${s.row_label}-${` | แท็ก/ข้อความ HTML อื่น ๆ |
| 272 | `                  s.seat_number` | แท็ก/ข้อความ HTML อื่น ๆ |
| 273 | `                } (${money(s.price)})`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 274 | `                return `<button data-id="${s.id}" ${` | แท็ก/ข้อความ HTML อื่น ๆ |
| 275 | `                  s.status !== "available" ? "disabled" : ""` | แท็ก/ข้อความ HTML อื่น ๆ |
| 276 | `                } style="margin:4px">${label}</button>`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 277 | `              })` | แท็ก/ข้อความ HTML อื่น ๆ |
| 278 | `              .join("") \|\| "<em>No seats</em>";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 279 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 280 | `          // admin log & my orders` | แท็ก/ข้อความ HTML อื่น ๆ |
| 281 | `          if (amAdmin) await loadAdminOrders(e.id);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 282 | `          if (!amAdmin && loggedIn) await loadMyOrdersForEvent(e.id);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 283 | `        } catch (err) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 284 | `          eventInfo.innerHTML = `<span style="color:#d33">${err.message}</span>`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 285 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 286 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 287 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 288 | `      // seat selection` | แท็ก/ข้อความ HTML อื่น ๆ |
| 289 | `      document.addEventListener("click", (e) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 290 | `        if (e.target.parentElement?.id === "seats" && e.target.dataset.id) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 291 | `          const id = Number(e.target.dataset.id);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 292 | `          if (selected.has(id)) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 293 | `            selected.delete(id);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 294 | `            e.target.style.outline = "";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 295 | `          } else {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 296 | `            selected.add(id);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 297 | `            e.target.style.outline = "2px solid #09f";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 298 | `          }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 299 | `          renderSelected();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 300 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 301 | `      });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 302 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 303 | `      // buy` | แท็ก/ข้อความ HTML อื่น ๆ |
| 304 | `      buyBtn.onclick = async () => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 305 | `        if (!loggedIn) return (location.href = "login.html");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 306 | `        const eventId = seatsDiv.dataset.eventId;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 307 | `        const r = await fetch(`/api/events/${eventId}/orders`, {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 308 | `          method: "POST",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 309 | `          headers: { "Content-Type": "application/json", ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 310 | `          body: JSON.stringify({ seatIds: [...selected] }),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 311 | `        });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 312 | `        const d = await r.json();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 313 | `        if (!r.ok) return alert(d.error \|\| "order failed");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 314 | `        alert("Order #" + d.id);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 315 | `        await loadByMatch();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 316 | `      };` | แท็ก/ข้อความ HTML อื่น ๆ |
| 317 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 318 | `      /* ===== admin log (ย่อ) ===== */` | แท็ก/ข้อความ HTML อื่น ๆ |
| 319 | `      async function loadAdminOrders(eventId) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 320 | `        const pane = document.getElementById("adminOrders");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 321 | `        if (!pane) return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 322 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 323 | `        const status =` | แท็ก/ข้อความ HTML อื่น ๆ |
| 324 | `          (document.getElementById("adminFilter") \|\| {}).value \|\| "all";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 325 | `        const limit = Number(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 326 | `          (document.getElementById("adminLimit") \|\| {}).value \|\| 10` | แท็ก/ข้อความ HTML อื่น ๆ |
| 327 | `        );` | แท็ก/ข้อความ HTML อื่น ๆ |
| 328 | `        const showCanceled = !!(document.getElementById("showCanceled") \|\| {})` | แท็ก/ข้อความ HTML อื่น ๆ |
| 329 | `          .checked;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 330 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 331 | `        const all = await fetchJSON(`/api/events/${eventId}/orders`, {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 332 | `          headers: { ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 333 | `        });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 334 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 335 | `        const filtered = (all \|\| [])` | แท็ก/ข้อความ HTML อื่น ๆ |
| 336 | `          .filter((g) => (status === "all" ? true : g.order.status === status))` | แท็ก/ข้อความ HTML อื่น ๆ |
| 337 | `          .filter((g) => (showCanceled ? true : g.order.status !== "canceled"))` | แท็ก/ข้อความ HTML อื่น ๆ |
| 338 | `          .slice(0, limit);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 339 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 340 | `        pane.innerHTML =` | แท็ก/ข้อความ HTML อื่น ๆ |
| 341 | `          filtered` | แท็ก/ข้อความ HTML อื่น ๆ |
| 342 | `            .map(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 343 | `              (g) => `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 344 | `            <details style="border:1px solid #ddd;border-radius:8px;margin:8px 0">` | แท็ก/ข้อความ HTML อื่น ๆ |
| 345 | `              <summary style="padding:6px 8px;cursor:pointer">` | แท็ก/ข้อความ HTML อื่น ๆ |
| 346 | `                <strong>#${g.order.id}</strong> — user: ${g.order.user_ref}` | แท็ก/ข้อความ HTML อื่น ๆ |
| 347 | `                — ${money(g.order.total)} — ${g.order.status}` | แท็ก/ข้อความ HTML อื่น ๆ |
| 348 | `                — ${new Date(g.order.created_at).toLocaleString()}` | แท็ก/ข้อความ HTML อื่น ๆ |
| 349 | `              </summary>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 350 | `              <div style="padding:8px">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 351 | `                <div>Items: ${` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 352 | `                  (g.items \|\| [])` | แท็ก/ข้อความ HTML อื่น ๆ |
| 353 | `                    .map(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 354 | `                      (i) =>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 355 | `                        `${i.section}-${i.row_label}-${i.seat_number} (${money(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 356 | `                          i.price` | แท็ก/ข้อความ HTML อื่น ๆ |
| 357 | `                        )})`` | แท็ก/ข้อความ HTML อื่น ๆ |
| 358 | `                    )` | แท็ก/ข้อความ HTML อื่น ๆ |
| 359 | `                    .join(", ") \|\| "-"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 360 | `                }</div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 361 | `                <div style="margin-top:6px">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 362 | `                  ${` | แท็ก/ข้อความ HTML อื่น ๆ |
| 363 | `                    g.order.status === "pending"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 364 | `                      ? `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 365 | `                         <!-- <button data-act="ad-mark-paid" data-id="${g.order.id}">Mark as Paid</button> -->` | คอมเมนต์ใน HTML (ไม่แสดงผล) |
| 366 | `                         <button data-act="ad-cancel" data-id="${g.order.id}">Cancel order</button>`` | ปุ่มกด |
| 367 | `                      : ""` | แท็ก/ข้อความ HTML อื่น ๆ |
| 368 | `                  }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 369 | `                  ${` | แท็ก/ข้อความ HTML อื่น ๆ |
| 370 | `                    g.order.status === "paid"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 371 | `                      ? (g.items \|\| [])` | แท็ก/ข้อความ HTML อื่น ๆ |
| 372 | `                          .map(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 373 | `                            (i) =>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 374 | `                              `<button data-act="ad-release" data-oid="${g.order.id}" data-seat="${i.seat_id}">Release ${i.seat_id}</button>`` | แท็ก/ข้อความ HTML อื่น ๆ |
| 375 | `                          )` | แท็ก/ข้อความ HTML อื่น ๆ |
| 376 | `                          .join(" ")` | แท็ก/ข้อความ HTML อื่น ๆ |
| 377 | `                      : ""` | แท็ก/ข้อความ HTML อื่น ๆ |
| 378 | `                  }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 379 | `                </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 380 | `              </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 381 | `            </details>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 382 | `          `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 383 | `            )` | แท็ก/ข้อความ HTML อื่น ๆ |
| 384 | `            .join("") \|\| "<em>No orders</em>";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 385 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 386 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 387 | `      // bind control ของ admin log (ป้องกัน null)` | แท็ก/ข้อความ HTML อื่น ๆ |
| 388 | `      if (amAdmin) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 389 | `        on("adminFilter", "change", () => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 390 | `          const id = seatsDiv.dataset.eventId;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 391 | `          if (id) loadAdminOrders(Number(id));` | แท็ก/ข้อความ HTML อื่น ๆ |
| 392 | `        });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 393 | `        on("showCanceled", "change", () => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 394 | `          const id = seatsDiv.dataset.eventId;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 395 | `          if (id) loadAdminOrders(Number(id));` | แท็ก/ข้อความ HTML อื่น ๆ |
| 396 | `        });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 397 | `        on("adminLimit", "change", () => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 398 | `          const id = seatsDiv.dataset.eventId;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 399 | `          if (id) loadAdminOrders(Number(id));` | แท็ก/ข้อความ HTML อื่น ๆ |
| 400 | `        });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 401 | `        on("reloadOrders", "click", () => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 402 | `          const id = seatsDiv.dataset.eventId;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 403 | `          if (id) loadAdminOrders(Number(id));` | แท็ก/ข้อความ HTML อื่น ๆ |
| 404 | `        });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 405 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 406 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 407 | `      // delegate ปุ่ม admin` | แท็ก/ข้อความ HTML อื่น ๆ |
| 408 | `      if (amAdmin && !window.__adminOrderDelegationBound) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 409 | `        window.__adminOrderDelegationBound = true;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 410 | `        document.addEventListener(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 411 | `          "click",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 412 | `          async (ev) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 413 | `            const t = ev.target;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 414 | `            if (!t?.dataset) return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 415 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 416 | `            if (t.dataset.act === "ad-mark-paid") {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 417 | `              const id = Number(t.dataset.id);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 418 | `              try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 419 | `                await fetchJSON(`/api/orders/${id}/mark-paid`, {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 420 | `                  method: "POST",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 421 | `                  headers: { ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 422 | `                });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 423 | `                const evId = Number(seatsDiv.dataset.eventId);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 424 | `                if (evId) await loadAdminOrders(evId);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 425 | `              } catch (e) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 426 | `                alert(e.message);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 427 | `              }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 428 | `            }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 429 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 430 | `            if (t.dataset.act === "ad-cancel") {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 431 | `              const id = Number(t.dataset.id);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 432 | `              if (!confirm(`Cancel order #${id}?`)) return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 433 | `              try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 434 | `                const d = await fetchJSON(`/api/orders/${id}/cancel`, {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 435 | `                  method: "POST",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 436 | `                  headers: { ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 437 | `                });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 438 | `                alert(`Canceled. Released ${d.released} seats.`);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 439 | `                const evId = Number(seatsDiv.dataset.eventId);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 440 | `                if (evId) await loadAdminOrders(evId);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 441 | `              } catch (e) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 442 | `                alert(e.message);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 443 | `              }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 444 | `            }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 445 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 446 | `            if (t.dataset.act === "ad-release") {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 447 | `              const oid = Number(t.dataset.oid);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 448 | `              const seatId = Number(t.dataset.seat);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 449 | `              if (!confirm(`Release seat ${seatId} from order #${oid}?`))` | แท็ก/ข้อความ HTML อื่น ๆ |
| 450 | `                return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 451 | `              try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 452 | `                await fetchJSON(`/api/orders/${oid}/release-seat`, {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 453 | `                  method: "POST",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 454 | `                  headers: {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 455 | `                    "Content-Type": "application/json",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 456 | `                    ...authHeaders(),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 457 | `                  },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 458 | `                  body: JSON.stringify({ seat_id: seatId }),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 459 | `                });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 460 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 461 | `                // ✅ หลัง release ให้เปลี่ยนสถานะ order เป็น canceled` | แท็ก/ข้อความ HTML อื่น ๆ |
| 462 | `                await fetchJSON(`/api/orders/${oid}/cancel`, {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 463 | `                  method: "POST",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 464 | `                  headers: { ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 465 | `                });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 466 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 467 | `                alert(`Released seat ${seatId} and canceled order #${oid}`);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 468 | `                const evId = Number(seatsDiv.dataset.eventId);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 469 | `                if (evId) await loadAdminOrders(evId);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 470 | `              } catch (e) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 471 | `                alert(e.message);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 472 | `              }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 473 | `            }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 474 | `          },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 475 | `          { capture: true }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 476 | `        );` | แท็ก/ข้อความ HTML อื่น ๆ |
| 477 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 478 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 479 | `      /* ===== user: my pending orders ===== */` | แท็ก/ข้อความ HTML อื่น ๆ |
| 480 | `      async function loadMyOrdersForEvent(eventId) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 481 | `        const box = document.getElementById("myOrders");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 482 | `        if (!box) return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 483 | `        box.innerHTML = "Loading...";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 484 | `        try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 485 | `          const data = await fetchJSON(`/api/my/orders?eventId=${eventId}`, {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 486 | `            headers: { ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 487 | `          });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 488 | `          const rows = (data \|\| []).filter((g) => g.order.status === "pending");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 489 | `          box.innerHTML =` | แท็ก/ข้อความ HTML อื่น ๆ |
| 490 | `            rows` | แท็ก/ข้อความ HTML อื่น ๆ |
| 491 | `              .map(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 492 | `                (g) => `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 493 | `              <div class="order-card" style="border:1px solid #ddd;border-radius:8px;margin:8px 0;padding:8px">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 494 | `                <div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 495 | `                  <strong>Order #${g.order.id}</strong> —` | แท็ก/ข้อความ HTML อื่น ๆ |
| 496 | `                  total: ${money(g.order.total)} —` | แท็ก/ข้อความ HTML อื่น ๆ |
| 497 | `                  status: ${g.order.status} —` | แท็ก/ข้อความ HTML อื่น ๆ |
| 498 | `                  created: ${new Date(g.order.created_at).toLocaleString()}` | แท็ก/ข้อความ HTML อื่น ๆ |
| 499 | `                </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 500 | `                <div>Items: ${` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 501 | `                  (g.items \|\| [])` | แท็ก/ข้อความ HTML อื่น ๆ |
| 502 | `                    .map(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 503 | `                      (i) =>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 504 | `                        `${i.section}-${i.row_label}-${i.seat_number} (${money(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 505 | `                          i.price` | แท็ก/ข้อความ HTML อื่น ๆ |
| 506 | `                        )})`` | แท็ก/ข้อความ HTML อื่น ๆ |
| 507 | `                    )` | แท็ก/ข้อความ HTML อื่น ๆ |
| 508 | `                    .join(", ") \|\| "-"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 509 | `                }</div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 510 | `                <div style="margin-top:6px">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 511 | `                  <button data-act="my-cancel" data-id="${` | ปุ่มกด |
| 512 | `                    g.order.id` | แท็ก/ข้อความ HTML อื่น ๆ |
| 513 | `                  }">Cancel this order</button>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 514 | `                </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 515 | `              </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 516 | `            `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 517 | `              )` | แท็ก/ข้อความ HTML อื่น ๆ |
| 518 | `              .join("") \|\| "<em>No pending orders</em>";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 519 | `        } catch (err) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 520 | `          box.innerHTML = `<span style="color:#d33">${err.message}</span>`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 521 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 522 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 523 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 524 | `      // delegate: cancel (user)` | แท็ก/ข้อความ HTML อื่น ๆ |
| 525 | `      if (loggedIn && !amAdmin) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 526 | `        document.addEventListener("click", async (e) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 527 | `          if (e.target.dataset.act !== "my-cancel") return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 528 | `          const orderId = Number(e.target.dataset.id);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 529 | `          if (!confirm(`Cancel order #${orderId}?`)) return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 530 | `          try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 531 | `            const d = await fetchJSON(`/api/my/orders/${orderId}/cancel`, {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 532 | `              method: "POST",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 533 | `              headers: { ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 534 | `            });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 535 | `            alert(`Canceled order #${orderId}. Released ${d.released} seats.`);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 536 | `            e.target.closest(".order-card")?.remove();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 537 | `          } catch (err) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 538 | `            alert(err.message);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 539 | `          }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 540 | `        });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 541 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 542 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 543 | `      /* ===== admin: forms ===== */` | แท็ก/ข้อความ HTML อื่น ๆ |
| 544 | `      if (amAdmin) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 545 | `        on("createEvent", "submit", async (ev) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 546 | `          ev.preventDefault();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 547 | `          const f = Object.fromEntries(new FormData(ev.target));` | แท็ก/ข้อความ HTML อื่น ๆ |
| 548 | `          const body = {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 549 | `            match_id: Number(f.match_id),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 550 | `            sales_open_at: toISO(f.sales_open_at),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 551 | `            sales_close_at: toISO(f.sales_close_at),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 552 | `          };` | แท็ก/ข้อความ HTML อื่น ๆ |
| 553 | `          try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 554 | `            const d = await fetchJSON("/api/events", {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 555 | `              method: "POST",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 556 | `              headers: { "Content-Type": "application/json", ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 557 | `              body: JSON.stringify(body),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 558 | `            });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 559 | `            alert(`Created/Updated event #${d.id}`);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 560 | `            matchInput.value = body.match_id;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 561 | `            await loadByMatch();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 562 | `          } catch (e) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 563 | `            alert(e.message);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 564 | `          }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 565 | `        });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 566 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 567 | `        on("addSeats", "submit", async (ev) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 568 | `          ev.preventDefault();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 569 | `          const fd = new FormData(ev.target);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 570 | `          const eventId = Number(fd.get("eventId"));` | แท็ก/ข้อความ HTML อื่น ๆ |
| 571 | `          const lines = (fd.get("rows") \|\| "")` | แท็ก/ข้อความ HTML อื่น ๆ |
| 572 | `            .split(/\r?\n/)` | แท็ก/ข้อความ HTML อื่น ๆ |
| 573 | `            .map((s) => s.trim())` | แท็ก/ข้อความ HTML อื่น ๆ |
| 574 | `            .filter(Boolean);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 575 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 576 | `          let seats;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 577 | `          try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 578 | `            seats = lines.map((line) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 579 | `              const o = JSON.parse(line);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 580 | `              return {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 581 | `                section: o.section,` | แท็ก/ข้อความ HTML อื่น ๆ |
| 582 | `                row_label: o.row_label,` | แท็ก/ข้อความ HTML อื่น ๆ |
| 583 | `                seat_number: Number(o.seat_number),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 584 | `                price: Number(o.price),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 585 | `              };` | แท็ก/ข้อความ HTML อื่น ๆ |
| 586 | `            });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 587 | `          } catch {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 588 | `            return alert("รูปแบบ JSON ไม่ถูกต้องในบางบรรทัด");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 589 | `          }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 590 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 591 | `          try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 592 | `            await fetchJSON(`/api/events/${eventId}/seats`, {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 593 | `              method: "POST",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 594 | `              headers: { "Content-Type": "application/json", ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 595 | `              body: JSON.stringify({ seats }),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 596 | `            });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 597 | `            alert("Seats added/updated");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 598 | `            await loadByMatch();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 599 | `          } catch (e) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 600 | `            alert(e.message);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 601 | `          }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 602 | `        });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 603 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 604 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 605 | `      if (amAdmin) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 606 | `        const seedBtn = document.getElementById("seedDefaultSeats");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 607 | `        if (seedBtn) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 608 | `          seedBtn.addEventListener("click", async () => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 609 | `            const evIdInput = document.querySelector(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 610 | `              '#addSeats [name="eventId"]'` | แท็ก/ข้อความ HTML อื่น ๆ |
| 611 | `            );` | แท็ก/ข้อความ HTML อื่น ๆ |
| 612 | `            const eventId = Number(evIdInput?.value \|\| 0);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 613 | `            if (!eventId) return alert("กรุณาใส่ eventId ให้ถูกต้องก่อน");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 614 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 615 | `            // ชุดมาตรฐาน: A=1..10 ราคา 800, B=1..10 ราคา 500` | แท็ก/ข้อความ HTML อื่น ๆ |
| 616 | `            const seats = [];` | แท็ก/ข้อความ HTML อื่น ๆ |
| 617 | `            for (let i = 1; i <= 10; i++) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 618 | `              seats.push({` | แท็ก/ข้อความ HTML อื่น ๆ |
| 619 | `                section: "A",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 620 | `                row_label: "A",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 621 | `                seat_number: i,` | แท็ก/ข้อความ HTML อื่น ๆ |
| 622 | `                price: 800,` | แท็ก/ข้อความ HTML อื่น ๆ |
| 623 | `              });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 624 | `            }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 625 | `            for (let i = 1; i <= 10; i++) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 626 | `              seats.push({` | แท็ก/ข้อความ HTML อื่น ๆ |
| 627 | `                section: "B",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 628 | `                row_label: "B",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 629 | `                seat_number: i,` | แท็ก/ข้อความ HTML อื่น ๆ |
| 630 | `                price: 500,` | แท็ก/ข้อความ HTML อื่น ๆ |
| 631 | `              });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 632 | `            }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 633 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 634 | `            try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 635 | `              await fetchJSON(`/api/events/${eventId}/seats`, {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 636 | `                method: "POST",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 637 | `                headers: {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 638 | `                  "Content-Type": "application/json",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 639 | `                  ...authHeaders(),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 640 | `                },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 641 | `                body: JSON.stringify({ seats }),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 642 | `              });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 643 | `              alert("Seats generated/updated");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 644 | `              await loadByMatch(); // รีเฟรชที่นั่ง` | แท็ก/ข้อความ HTML อื่น ๆ |
| 645 | `            } catch (e) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 646 | `              alert(e.message);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 647 | `            }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 648 | `          });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 649 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 650 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 651 | `      /* ===== initial ===== */` | แท็ก/ข้อความ HTML อื่น ๆ |
| 652 | `      buyBtn.disabled = !loggedIn;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 653 | `      on("find", "click", loadByMatch);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 654 | `      // เปลี่ยน limit แล้วกด Enter ให้ทำงาน` | แท็ก/ข้อความ HTML อื่น ๆ |
| 655 | `      on("adminLimit", "keyup", (e) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 656 | `        if (e.key === "Enter") {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 657 | `          const id = seatsDiv.dataset.eventId;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 658 | `          if (id) loadAdminOrders(Number(id));` | แท็ก/ข้อความ HTML อื่น ๆ |
| 659 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 660 | `      });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 661 | `      loadByMatch();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 662 | `    </script>` | ปิดสคริปต์ |
| 663 | `  </body>` | ปิด body |
| 664 | `</html>` | ปิดเอกสาร HTML |
