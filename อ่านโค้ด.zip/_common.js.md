# _common.js — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `// ===== helpers ใช้ร่วมกันทุกหน้า =====` | คอมเมนต์อธิบายโค้ด |
| 2 | `const token = localStorage.getItem("token") \|\| "";` | อ่าน/เขียน token ลง localStorage ของเบราว์เซอร์ |
| 3 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 4 | `function me() {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 5 | `  try { return token ? JSON.parse(atob(token.split(".")[1])) : null; }` | เริ่มบล็อก try เพื่อดักจับข้อผิดพลาด |
| 6 | `  catch { return null; }` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 7 | `}` | ปิดบล็อก/ปิดคำสั่ง |
| 8 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 9 | `function authHeaders() {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 10 | `  return token ? { Authorization: "Bearer " + token } : {};` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 11 | `}` | ปิดบล็อก/ปิดคำสั่ง |
| 12 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 13 | `function requireLogin() {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 14 | `  if (!token) { alert("กรุณา Login ก่อน"); location.href = "login.html"; }` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 15 | `}` | ปิดบล็อก/ปิดคำสั่ง |
| 16 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 17 | `function isAdmin() {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 18 | `  return (me()?.roles \|\| []).includes("admin");` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 19 | `}` | ปิดบล็อก/ปิดคำสั่ง |
| 20 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 21 | `function navBar(active) {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 22 | `  const t = localStorage.getItem("token");` | อ่าน/เขียน token ลง localStorage ของเบราว์เซอร์ |
| 23 | `  const loggedIn = !!t;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 24 | `  return `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 25 | `  <nav style="display:flex;gap:14px;align-items:center;margin-bottom:14px">` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 26 | `    <a href="index.html"${active==="home"?' style="font-weight:700"':''}>Home</a>` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 27 | `    <a href="teams.html"${active==="teams"?' style="font-weight:700"':''}>Teams</a>` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 28 | `    <a href="players.html"${active==="players"?' style="font-weight:700"':''}>Players</a>` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 29 | `    <a href="matches.html"${active==="matches"?' style="font-weight:700"':''}>Matches</a>` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 30 | `    <a href="events.html"${active==="events"?' style="font-weight:700"':''}>Events</a>` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 31 | `    <a href="standings.html"${active==="standings"?' style="font-weight:700"':''}>Standings</a>` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 32 | `    ${loggedIn ? `<a href="ticket.html"${active==="mytickets"?' style="font-weight:700"':''}>My Tickets</a>` : ""}` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 33 | `    <span style="flex:1"></span>` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 34 | `    <span id="who" class="pill">${loggedIn ? (me().sub + " (" + ((me().roles\|\|[]).join("\|") \|\| "user") + ")") : "guest"}</span>` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 35 | `    ${loggedIn ? '<button id="logoutBtn">Logout</button>' : '<a href="login.html">Login</a>'}` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 36 | `  </nav>`;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 37 | `}` | ปิดบล็อก/ปิดคำสั่ง |
| 38 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 39 | `function bindLogout() {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 40 | `  const b = document.getElementById("logoutBtn");` | เลือก DOM element เพื่ออ่าน/แก้ไข UI |
| 41 | `  if (b) b.onclick = () => { localStorage.removeItem("token"); location.reload(); };` | อ่าน/เขียน token ลง localStorage ของเบราว์เซอร์ |
| 42 | `}` | ปิดบล็อก/ปิดคำสั่ง |
| 43 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 44 | `async function fetchJSON(url, options = {}) {` | ประกาศฟังก์ชันแบบ async รองรับ await |
| 45 | `  const res = await fetch(url, options);` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 46 | `  if (!res.ok) {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 47 | `    let errMsg = `HTTP ${res.status}`;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 48 | `    try { const data = await res.json(); errMsg = data.error \|\| data.message \|\| errMsg; }` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 49 | `    catch { try { errMsg = (await res.text()) \|\| errMsg; } catch {} }` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 50 | `    const err = new Error(errMsg); err.status = res.status; throw err;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 51 | `  }` | ปิดบล็อก/ปิดคำสั่ง |
| 52 | `  try { return await res.json(); } catch { return null; }` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 53 | `}` | ปิดบล็อก/ปิดคำสั่ง |
| 54 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 55 | `function gateGuestsOrRenderMsg() {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 56 | `    if (!me()) {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 57 | `      // ซ่อนทุกอย่างยกเว้น nav` | คอมเมนต์อธิบายโค้ด |
| 58 | `      [...document.body.children].forEach(el => { if (el.id !== 'nav') el.style.display = 'none'; });` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 59 | `      // ข้อความเตือน` | คอมเมนต์อธิบายโค้ด |
| 60 | `      document.body.insertAdjacentHTML(` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 61 | `        'beforeend',` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 62 | `        '<div class="guest-message">ต้องเข้าสู่ระบบก่อนเพื่อดูข้อมูล</div>'` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 63 | `      );` | ปิดบล็อก/ปิดคำสั่ง |
| 64 | `      return true; // บอกว่าเป็น guest` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 65 | `    }` | ปิดบล็อก/ปิดคำสั่ง |
| 66 | `    return false; // ล็อกอินอยู่ ดำเนินต่อได้` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 67 | `  }` | ปิดบล็อก/ปิดคำสั่ง |
