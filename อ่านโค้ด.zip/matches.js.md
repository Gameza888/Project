# matches.js — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `// routes/matches.js` | คอมเมนต์อธิบายโค้ด |
| 2 | `const express = require("express");` | นำเข้าโมดูลด้วย CommonJS (`require`) แล้วเก็บในตัวแปร `const` |
| 3 | `const router = express.Router();` | สร้าง Router ของ Express เพื่อประกาศเส้นทาง (routes) แยกไฟล์ |
| 4 | `const pool = require("../db");` | นำเข้าโมดูลด้วย CommonJS (`require`) แล้วเก็บในตัวแปร `const` |
| 5 | `const { requireAuth } = require("../middleware/auth");` | มิดเดิลแวร์บังคับยืนยันตัวตน |
| 6 | `const { hasRole } = require("../middleware/rbac");` | มิดเดิลแวร์ตรวจสิทธิ์บทบาท (RBAC) |
| 7 | `const { recomputeStandings } = require("./standings");` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 8 | `const standings = require('./standings');` | นำเข้าโมดูลด้วย CommonJS (`require`) แล้วเก็บในตัวแปร `const` |
| 9 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 10 | `// รายการแมตช์ (รวมชื่อทีม)` | คอมเมนต์อธิบายโค้ด |
| 11 | `router.get("/", async (_req, res) => {` | ประกาศเส้นทาง HTTP ของ Express ตามเมธอดและพาธ |
| 12 | `  const { rows } = await pool.query(`` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 13 | `    SELECT m.*,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 14 | `           ht.name AS home_name, at.name AS away_name` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 15 | `    FROM matches m` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 16 | `    JOIN teams ht ON ht.id = m.home_team_id` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 17 | `    JOIN teams at ON at.id = m.away_team_id` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 18 | `    ORDER BY m.tipoff_at DESC, m.id DESC` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 19 | `  `);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 20 | `  res.json(rows);` | ส่งข้อมูลกลับเป็น JSON ให้ client |
| 21 | `});` | ปิดบล็อก/ปิดคำสั่ง |
| 22 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 23 | `router.get("/:id", async (req, res) => {` | ประกาศเส้นทาง HTTP ของ Express ตามเมธอดและพาธ |
| 24 | `  const id = Number(req.params.id);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 25 | `  const { rows } = await pool.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 26 | `    `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 27 | `    SELECT m.*,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 28 | `           ht.name AS home_name,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 29 | `           at.name AS away_name` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 30 | `    FROM matches m` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 31 | `    JOIN teams ht ON ht.id = m.home_team_id` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 32 | `    JOIN teams at ON at.id = m.away_team_id` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 33 | `    WHERE m.id = $1` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 34 | `  `,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 35 | `    [id]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 36 | `  );` | ปิดบล็อก/ปิดคำสั่ง |
| 37 | `  if (!rows[0]) return res.status(404).json({ error: "Not found" });` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 38 | `  res.json(rows[0]);` | ส่งข้อมูลกลับเป็น JSON ให้ client |
| 39 | `});` | ปิดบล็อก/ปิดคำสั่ง |
| 40 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 41 | `// สร้าง match (admin)` | คอมเมนต์อธิบายโค้ด |
| 42 | `router.post("/", requireAuth, hasRole("admin"), async (req, res) => {` | ประกาศเส้นทาง HTTP ของ Express ตามเมธอดและพาธ |
| 43 | `  try {` | เริ่มบล็อก try เพื่อดักจับข้อผิดพลาด |
| 44 | `    const { home_team_id, away_team_id, tipoff_at, venue } = req.body;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 45 | `    if (!home_team_id \|\| !away_team_id \|\| !tipoff_at)` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 46 | `      return res` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 47 | `        .status(400)` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 48 | `        .json({ error: "home_team_id, away_team_id, tipoff_at are required" });` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 49 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 50 | `    const { rows } = await pool.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 51 | `      `INSERT INTO matches (home_team_id, away_team_id, tipoff_at, venue, status)` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 52 | `       VALUES ($1,$2,$3,$4,'scheduled') RETURNING *`,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 53 | `      [Number(home_team_id), Number(away_team_id), tipoff_at, venue \|\| null]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 54 | `    );` | ปิดบล็อก/ปิดคำสั่ง |
| 55 | `    res.status(201).json(rows[0]);` | กำหนดรหัสสถานะ HTTP ก่อนส่งคำตอบ |
| 56 | `  } catch (e) {` | จับข้อผิดพลาด (exception) ที่เกิดในบล็อก try |
| 57 | `    res.status(400).json({ error: e.message });` | กำหนดรหัสสถานะ HTTP ก่อนส่งคำตอบ |
| 58 | `  }` | ปิดบล็อก/ปิดคำสั่ง |
| 59 | `});` | ปิดบล็อก/ปิดคำสั่ง |
| 60 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 61 | `router.post("/events", requireAuth, hasRole("admin"), async (req, res) => {` | ประกาศเส้นทาง HTTP ของ Express ตามเมธอดและพาธ |
| 62 | `  try {` | เริ่มบล็อก try เพื่อดักจับข้อผิดพลาด |
| 63 | `    const { match_id, sales_open_at, sales_close_at } = req.body;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 64 | `    const { rows } = await pool.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 65 | `      `INSERT INTO event(match_id, sales_open_at, sales_close_at)` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 66 | `       VALUES ($1,$2,$3)` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 67 | `       ON CONFLICT (match_id)` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 68 | `       DO UPDATE SET` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 69 | `         sales_open_at = EXCLUDED.sales_open_at,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 70 | `         sales_close_at = EXCLUDED.sales_close_at` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 71 | `       RETURNING *`,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 72 | `      [Number(match_id), sales_open_at \|\| null, sales_close_at \|\| null]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 73 | `    );` | ปิดบล็อก/ปิดคำสั่ง |
| 74 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 75 | `    res.status(201).json(rows[0]);` | กำหนดรหัสสถานะ HTTP ก่อนส่งคำตอบ |
| 76 | `  } catch (e) {` | จับข้อผิดพลาด (exception) ที่เกิดในบล็อก try |
| 77 | `    console.error("POST /api/events error:", e);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 78 | `    res.status(400).json({ error: e.message });` | กำหนดรหัสสถานะ HTTP ก่อนส่งคำตอบ |
| 79 | `  }` | ปิดบล็อก/ปิดคำสั่ง |
| 80 | `});` | ปิดบล็อก/ปิดคำสั่ง |
| 81 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 82 | `router.get("/:id", async (req, res) => {` | ประกาศเส้นทาง HTTP ของ Express ตามเมธอดและพาธ |
| 83 | `  const id = Number(req.params.id);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 84 | `  const { rows } = await pool.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 85 | `    `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 86 | `    SELECT m.*,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 87 | `           ht.name AS home_name, at.name AS away_name,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 88 | `           ht.short_code AS home_code, at.short_code AS away_code` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 89 | `    FROM matches m` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 90 | `    JOIN teams ht ON ht.id = m.home_team_id` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 91 | `    JOIN teams at ON at.id = m.away_team_id` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 92 | `    WHERE m.id = $1` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 93 | `  `,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 94 | `    [id]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 95 | `  );` | ปิดบล็อก/ปิดคำสั่ง |
| 96 | `  if (!rows[0]) return res.status(404).json({ error: "match not found" });` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 97 | `  res.json(rows[0]);` | ส่งข้อมูลกลับเป็น JSON ให้ client |
| 98 | `});` | ปิดบล็อก/ปิดคำสั่ง |
| 99 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 100 | `// อัปเดตสกอร์/สถานะ (admin)` | คอมเมนต์อธิบายโค้ด |
| 101 | `// PUT /api/matches/:id/score` | คอมเมนต์อธิบายโค้ด |
| 102 | `router.put("/:id/score", requireAuth, hasRole("admin"), async (req, res) => {` | ประกาศเส้นทาง HTTP ของ Express ตามเมธอดและพาธ |
| 103 | `  const id = Number(req.params.id);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 104 | `  const { home_score, away_score, status } = req.body;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 105 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 106 | `  try {` | เริ่มบล็อก try เพื่อดักจับข้อผิดพลาด |
| 107 | `    if (status === "canceled") {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 108 | `      // อัปเดตเฉพาะสถานะ` | คอมเมนต์อธิบายโค้ด |
| 109 | `      const { rows } = await pool.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 110 | `        `UPDATE matches SET status=$1 WHERE id=$2 RETURNING *`,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 111 | `        ["canceled", id]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 112 | `      );` | ปิดบล็อก/ปิดคำสั่ง |
| 113 | `      if (!rows[0]) return res.status(404).json({ error: "Not found" });` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 114 | `      return res.json(rows[0]);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 115 | `    }` | ปิดบล็อก/ปิดคำสั่ง |
| 116 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 117 | `    // กรณีอื่น ๆ ต้องมีสกอร์` | คอมเมนต์อธิบายโค้ด |
| 118 | `    if (home_score == null \|\| away_score == null) {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 119 | `      return res.status(400).json({` | ส่งสถานะ HTTP และข้อความ error กลับไปยัง client แล้วจบการทำงาน |
| 120 | `        error: "home_score and away_score are required unless status=canceled",` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 121 | `      });` | ปิดบล็อก/ปิดคำสั่ง |
| 122 | `    }` | ปิดบล็อก/ปิดคำสั่ง |
| 123 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 124 | `    const { rows } = await pool.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 125 | `      `UPDATE matches` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 126 | `       SET home_score=$1, away_score=$2, status=$3` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 127 | `       WHERE id=$4 RETURNING *`,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 128 | `      [Number(home_score), Number(away_score), status \|\| "finished", id]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 129 | `    );` | ปิดบล็อก/ปิดคำสั่ง |
| 130 | `    await standings.recomputeStandings();` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 131 | `    if (!rows[0]) return res.status(404).json({ error: "Not found" });` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 132 | `    res.json(rows[0]);` | ส่งข้อมูลกลับเป็น JSON ให้ client |
| 133 | `  } catch (e) {` | จับข้อผิดพลาด (exception) ที่เกิดในบล็อก try |
| 134 | `    res.status(400).json({ error: e.message });` | กำหนดรหัสสถานะ HTTP ก่อนส่งคำตอบ |
| 135 | `  }` | ปิดบล็อก/ปิดคำสั่ง |
| 136 | `});` | ปิดบล็อก/ปิดคำสั่ง |
| 137 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 138 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 139 | `router.delete("/:id", requireAuth, hasRole("admin"), async (req, res) => {` | ประกาศเส้นทาง HTTP ของ Express ตามเมธอดและพาธ |
| 140 | `  const id = Number(req.params.id);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 141 | `  const client = await pool.connect();` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 142 | `  try {` | เริ่มบล็อก try เพื่อดักจับข้อผิดพลาด |
| 143 | `    await client.query("BEGIN");` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 144 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 145 | `    // หา event ทั้งหมดของแมตช์นี้` | คอมเมนต์อธิบายโค้ด |
| 146 | `    const { rows: evs } = await client.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 147 | `      "SELECT id FROM event WHERE match_id=$1",` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 148 | `      [id]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 149 | `    );` | ปิดบล็อก/ปิดคำสั่ง |
| 150 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 151 | `    // ลบของที่โยงกับแต่ละ event (ลำดับ: order_items -> orders -> seats -> event)` | คอมเมนต์อธิบายโค้ด |
| 152 | `    for (const ev of evs) {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 153 | `      await client.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 154 | `        "DELETE FROM order_items WHERE order_id IN (SELECT id FROM orders WHERE event_id=$1)",` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 155 | `        [ev.id]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 156 | `      );` | ปิดบล็อก/ปิดคำสั่ง |
| 157 | `      await client.query("DELETE FROM orders WHERE event_id=$1", [ev.id]);` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 158 | `      await client.query("DELETE FROM seats WHERE event_id=$1", [ev.id]);` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 159 | `    }` | ปิดบล็อก/ปิดคำสั่ง |
| 160 | `    await client.query("DELETE FROM event WHERE match_id=$1", [id]);` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 161 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 162 | `    // ลบ match` | คอมเมนต์อธิบายโค้ด |
| 163 | `    const { rowCount } = await client.query("DELETE FROM matches WHERE id=$1", [` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 164 | `      id,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 165 | `    ]);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 166 | `    await client.query("COMMIT");` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 167 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 168 | `    if (rowCount === 0) return res.status(404).json({ error: "Not found" });` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 169 | `    res.status(204).end();` | กำหนดรหัสสถานะ HTTP ก่อนส่งคำตอบ |
| 170 | `  } catch (e) {` | จับข้อผิดพลาด (exception) ที่เกิดในบล็อก try |
| 171 | `    await client.query("ROLLBACK");` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 172 | `    res.status(400).json({ error: e.message });` | กำหนดรหัสสถานะ HTTP ก่อนส่งคำตอบ |
| 173 | `  } finally {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 174 | `    client.release();` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 175 | `  }` | ปิดบล็อก/ปิดคำสั่ง |
| 176 | `});` | ปิดบล็อก/ปิดคำสั่ง |
| 177 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 178 | `router.put('/:id/score', async (req, res, next) => {` | ประกาศเส้นทาง HTTP ของ Express ตามเมธอดและพาธ |
| 179 | `  const id = Number(req.params.id);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 180 | `  const { home_score, away_score, status } = req.body \|\| {};` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 181 | `  try {` | เริ่มบล็อก try เพื่อดักจับข้อผิดพลาด |
| 182 | `    const { rows } = await pool.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 183 | `      `UPDATE matches` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 184 | `       SET home_score=$1, away_score=$2, status=$3` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 185 | `       WHERE id=$4 RETURNING *`,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 186 | `      [Number(home_score), Number(away_score), status \|\| 'finished', id]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 187 | `    );` | ปิดบล็อก/ปิดคำสั่ง |
| 188 | `    if (!rows.length) return res.status(404).json({ error: 'Match not found' });` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 189 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 190 | `    await standings.recomputeStandings(); // <- **คำนวณใหม่**` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 191 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 192 | `    res.json({ ok: true, match: rows[0] });` | ส่งข้อมูลกลับเป็น JSON ให้ client |
| 193 | `  } catch (err) {` | จับข้อผิดพลาด (exception) ที่เกิดในบล็อก try |
| 194 | `    console.error('PUT /api/matches/:id/score error:', err);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 195 | `    next(err);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 196 | `  }` | ปิดบล็อก/ปิดคำสั่ง |
| 197 | `});` | ปิดบล็อก/ปิดคำสั่ง |
| 198 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 199 | `module.exports = router;` | ส่งออกค่าจากไฟล์ (CommonJS) ให้ไฟล์อื่น `require` ไปใช้ |
