# players.html — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `<!-- public/players.html -->` | คอมเมนต์ใน HTML (ไม่แสดงผล) |
| 2 | `<!DOCTYPE html>` | ประกาศชนิดเอกสาร HTML5 |
| 3 | `<html lang="th">` | แท็ก `<html>` ครอบทั้งเอกสาร และกำหนดภาษา |
| 4 | `<head>` | หัวเอกสาร: meta, title, link, script ที่ไม่แสดงตรงๆ |
| 5 | `  <meta charset="utf-8" />` | กำหนดเมตาดาต้า (เช่น charset) |
| 6 | `  <title>Players</title>` | กำหนดชื่อหน้า (แสดงบนแท็บเบราว์เซอร์) |
| 7 | `  <link rel="stylesheet" href="css/style.css" />` | ลิงก์ไฟล์ภายนอก (เช่น CSS) |
| 8 | `  <style>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 9 | `    .guest-message { margin: 18px 0 0 0; color:#444; }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 10 | `  </style>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 11 | `</head>` | ปิดส่วน head |
| 12 | `<body>` | ส่วนเนื้อหาเพจที่จะมองเห็น |
| 13 | `  <div id="nav"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 14 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 15 | `  <h2>Players</h2>` | หัวข้อข้อความ |
| 16 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 17 | `  <!-- เกตสำหรับ guest -->` | คอมเมนต์ใน HTML (ไม่แสดงผล) |
| 18 | `  <div id="guestGate" class="guest-message" style="display:none">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 19 | `    ต้องเข้าสู่ระบบก่อนเพื่อดูข้อมูล` | แท็ก/ข้อความ HTML อื่น ๆ |
| 20 | `  </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 21 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 22 | `  <table id="playersTable">` | ตารางข้อมูล |
| 23 | `    <thead>` | ตารางข้อมูล |
| 24 | `      <tr><th>Team</th><th>Name</th><th>Pos</th><th>#</th></tr>` | ตารางข้อมูล |
| 25 | `    </thead>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 26 | `    <tbody id="rows"></tbody>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 27 | `  </table>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 28 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 29 | `  <section id="admin" style="display:none; margin-top:16px">` | แท็ก/ข้อความ HTML อื่น ๆ |
| 30 | `    <h3>+ Add Player (admin)</h3>` | หัวข้อข้อความ |
| 31 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 32 | `    <form id="create">` | ฟอร์มส่งข้อมูล |
| 33 | `      <select name="team_id" id="teamId" required></select>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 34 | `      <input name="first_name" placeholder="first name" />` | ช่องกรอกข้อมูลในฟอร์ม |
| 35 | `      <input name="last_name"  placeholder="last name" />` | ช่องกรอกข้อมูลในฟอร์ม |
| 36 | `      <input name="position"   placeholder="position (e.g. PG, SG)" />` | ช่องกรอกข้อมูลในฟอร์ม |
| 37 | `      <input name="jersey_number" type="number" placeholder="number" />` | ช่องกรอกข้อมูลในฟอร์ม |
| 38 | `      <button>Add</button>` | ปุ่มกด |
| 39 | `    </form>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 40 | `    <span id="msg" style="margin-left:8px;color:#d33"></span>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 41 | `  </section>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 42 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 43 | `  <script src="_common.js"></script>` | ฝัง/ลิงก์สคริปต์ JavaScript |
| 44 | `  <script>` | ฝัง/ลิงก์สคริปต์ JavaScript |
| 45 | `    document.getElementById('nav').innerHTML = navBar('players');` | แท็ก/ข้อความ HTML อื่น ๆ |
| 46 | `    bindLogout();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 47 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 48 | `    // -------- helpers --------` | แท็ก/ข้อความ HTML อื่น ๆ |
| 49 | `    async function fetchJSON(url, options={}) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 50 | `      const r = await fetch(url, options);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 51 | `      if (!r.ok) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 52 | `        let msg = `HTTP ${r.status}`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 53 | `        try { const d = await r.json(); msg = d.error \|\| d.message \|\| msg; } catch { try { msg = await r.text() \|\| msg; } catch {} }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 54 | `        const err = new Error(msg); err.status = r.status; throw err;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 55 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 56 | `      try { return await r.json(); } catch { return null; }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 57 | `    }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 58 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 59 | `    // ถ้าเป็น guest: ขึ้นข้อความและไม่ทำอะไรต่อ` | แท็ก/ข้อความ HTML อื่น ๆ |
| 60 | `    if (!me()) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 61 | `      document.querySelector('h2').style.display = 'none';` | แท็ก/ข้อความ HTML อื่น ๆ |
| 62 | `      document.getElementById('playersTable').style.display = 'none';` | แท็ก/ข้อความ HTML อื่น ๆ |
| 63 | `      document.getElementById('admin').style.display = 'none';` | แท็ก/ข้อความ HTML อื่น ๆ |
| 64 | `      document.getElementById('guestGate').style.display = 'block';` | แท็ก/ข้อความ HTML อื่น ๆ |
| 65 | `      // จบที่นี่ ไม่โหลดข้อมูล` | แท็ก/ข้อความ HTML อื่น ๆ |
| 66 | `    } else {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 67 | `      // ล็อกอินแล้ว → โหลดข้อมูลตามปกติ` | แท็ก/ข้อความ HTML อื่น ๆ |
| 68 | `      load();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 69 | `      if (isAdmin()) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 70 | `        document.getElementById('admin').style.display = 'block';` | แท็ก/ข้อความ HTML อื่น ๆ |
| 71 | `        loadTeamsForForm();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 72 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 73 | `    }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 74 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 75 | `    async function load() {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 76 | `      try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 77 | `        const rows = await fetchJSON('/api/players', { headers: { ...authHeaders() } });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 78 | `        document.getElementById('rows').innerHTML =` | แท็ก/ข้อความ HTML อื่น ๆ |
| 79 | `          (rows && rows.length ? rows : []).map(p => `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 80 | `            <tr>` | ตารางข้อมูล |
| 81 | `              <td>${p.team_name}</td>` | ตารางข้อมูล |
| 82 | `              <td>${(p.first_name\|\|'') + ' ' + (p.last_name\|\|'')}</td>` | ตารางข้อมูล |
| 83 | `              <td>${p.position \|\| '-'}</td>` | ตารางข้อมูล |
| 84 | `              <td>${p.jersey_number \|\| ''}</td>` | ตารางข้อมูล |
| 85 | `            </tr>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 86 | `          `).join('') \|\| '<tr><td colspan="4"><em>No players</em></td></tr>';` | แท็ก/ข้อความ HTML อื่น ๆ |
| 87 | `      } catch (err) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 88 | `        // ถ้า token หมดอายุให้เด้งไปล็อกอินใหม่` | แท็ก/ข้อความ HTML อื่น ๆ |
| 89 | `        if (err.status === 401) { localStorage.removeItem('token'); location.href='login.html'; return; }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 90 | `        document.getElementById('rows').innerHTML =` | แท็ก/ข้อความ HTML อื่น ๆ |
| 91 | `          `<tr><td colspan="4" style="color:#d33">${err.message}</td></tr>`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 92 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 93 | `    }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 94 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 95 | `    async function loadTeamsForForm() {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 96 | `      const teams = await fetchJSON('/api/teams', { headers: { ...authHeaders() } });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 97 | `      const sel = document.getElementById('teamId');` | แท็ก/ข้อความ HTML อื่น ๆ |
| 98 | `      sel.innerHTML = (teams \|\| []).map(t =>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 99 | `        `<option value="${t.id}">${t.short_code \|\| t.name} — ${t.name}</option>`` | แท็ก/ข้อความ HTML อื่น ๆ |
| 100 | `      ).join('');` | แท็ก/ข้อความ HTML อื่น ๆ |
| 101 | `    }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 102 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 103 | `    // onsubmit ฟอร์ม admin (ผูกครั้งเดียว)` | แท็ก/ข้อความ HTML อื่น ๆ |
| 104 | `    document.getElementById('create').onsubmit = async (e) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 105 | `      e.preventDefault();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 106 | `      const msg = document.getElementById('msg');` | แท็ก/ข้อความ HTML อื่น ๆ |
| 107 | `      msg.textContent = '';` | แท็ก/ข้อความ HTML อื่น ๆ |
| 108 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 109 | `      const body = Object.fromEntries(new FormData(e.target));` | แท็ก/ข้อความ HTML อื่น ๆ |
| 110 | `      body.team_id = Number(body.team_id);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 111 | `      body.jersey_number = body.jersey_number ? Number(body.jersey_number) : null;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 112 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 113 | `      try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 114 | `        const created = await fetchJSON('/api/players', {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 115 | `          method: 'POST',` | แท็ก/ข้อความ HTML อื่น ๆ |
| 116 | `          headers: { 'Content-Type': 'application/json', ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 117 | `          body: JSON.stringify(body)` | แท็ก/ข้อความ HTML อื่น ๆ |
| 118 | `        });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 119 | `        msg.style.color = '#0a0';` | แท็ก/ข้อความ HTML อื่น ๆ |
| 120 | `        msg.textContent = `Added #${created.id}`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 121 | `        e.target.reset();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 122 | `        await load();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 123 | `        await loadTeamsForForm();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 124 | `      } catch (err) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 125 | `        msg.style.color = '#d33';` | แท็ก/ข้อความ HTML อื่น ๆ |
| 126 | `        msg.textContent = err.message;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 127 | `        if (err.status === 401) { localStorage.removeItem('token'); location.href='login.html'; }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 128 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 129 | `    };` | แท็ก/ข้อความ HTML อื่น ๆ |
| 130 | `  </script>` | ปิดสคริปต์ |
| 131 | `</body>` | ปิด body |
| 132 | `</html>` | ปิดเอกสาร HTML |
