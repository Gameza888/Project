# teams.js — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `const express = require('express');` | นำเข้าโมดูลด้วย CommonJS (`require`) แล้วเก็บในตัวแปร `const` |
| 2 | `const pool = require('../db');` | นำเข้าโมดูลด้วย CommonJS (`require`) แล้วเก็บในตัวแปร `const` |
| 3 | `const { requireAuth } = require('../middleware/auth');` | มิดเดิลแวร์บังคับยืนยันตัวตน |
| 4 | `const { hasRole } = require('../middleware/rbac');` | มิดเดิลแวร์ตรวจสิทธิ์บทบาท (RBAC) |
| 5 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 6 | `const router = express.Router();` | สร้าง Router ของ Express เพื่อประกาศเส้นทาง (routes) แยกไฟล์ |
| 7 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 8 | `router.get('/', async (_req, res) => {` | ประกาศเส้นทาง HTTP ของ Express ตามเมธอดและพาธ |
| 9 | `  const { rows } = await pool.query('SELECT * FROM teams ORDER BY name');` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 10 | `  res.json(rows);` | ส่งข้อมูลกลับเป็น JSON ให้ client |
| 11 | `});` | ปิดบล็อก/ปิดคำสั่ง |
| 12 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 13 | `router.post('/', requireAuth, hasRole('admin'), async (req, res) => {` | ประกาศเส้นทาง HTTP ของ Express ตามเมธอดและพาธ |
| 14 | `  const { name, city, short_code } = req.body;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 15 | `  const { rows } = await pool.query(` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 16 | `    `INSERT INTO teams(name, city, short_code) VALUES ($1,$2,$3) RETURNING *`,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 17 | `    [name, city, short_code]` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 18 | `  );` | ปิดบล็อก/ปิดคำสั่ง |
| 19 | `  res.status(201).json(rows[0]);` | กำหนดรหัสสถานะ HTTP ก่อนส่งคำตอบ |
| 20 | `});` | ปิดบล็อก/ปิดคำสั่ง |
| 21 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 22 | `module.exports = router;` | ส่งออกค่าจากไฟล์ (CommonJS) ให้ไฟล์อื่น `require` ไปใช้ |
