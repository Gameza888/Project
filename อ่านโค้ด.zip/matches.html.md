# matches.html — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `<!DOCTYPE html>` | ประกาศชนิดเอกสาร HTML5 |
| 2 | `<html lang="th">` | แท็ก `<html>` ครอบทั้งเอกสาร และกำหนดภาษา |
| 3 | `  <head>` | หัวเอกสาร: meta, title, link, script ที่ไม่แสดงตรงๆ |
| 4 | `    <meta charset="utf-8" />` | กำหนดเมตาดาต้า (เช่น charset) |
| 5 | `    <title>Matches</title>` | กำหนดชื่อหน้า (แสดงบนแท็บเบราว์เซอร์) |
| 6 | `    <link rel="stylesheet" href="css/style.css" />` | ลิงก์ไฟล์ภายนอก (เช่น CSS) |
| 7 | `  </head>` | ปิดส่วน head |
| 8 | `  <body>` | ส่วนเนื้อหาเพจที่จะมองเห็น |
| 9 | `    <div id="nav"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 10 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 11 | `    <h2>Matches</h2>` | หัวข้อข้อความ |
| 12 | `    <div id="list"></div>` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 13 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 14 | `    <div id="admin" style="display: none">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 15 | `      <h3>+ Create match (admin)</h3>` | หัวข้อข้อความ |
| 16 | `      <form id="create">` | ฟอร์มส่งข้อมูล |
| 17 | `        <select id="homeTeam" name="home_team_id" required></select>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 18 | `        <select id="awayTeam" name="away_team_id" required></select>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 19 | `        <input name="tipoff_at" type="datetime-local" required />` | ช่องกรอกข้อมูลในฟอร์ม |
| 20 | `        <input name="venue" placeholder="venue" />` | ช่องกรอกข้อมูลในฟอร์ม |
| 21 | `        <button>Create</button>` | ปุ่มกด |
| 22 | `      </form>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 23 | `      <span id="msg" style="color: #d33"></span>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 24 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 25 | `      <h3>Update score/status</h3>` | หัวข้อข้อความ |
| 26 | `      <!-- ฟอร์มเดิม -->` | คอมเมนต์ใน HTML (ไม่แสดงผล) |
| 27 | `      <form id="score">` | ฟอร์มส่งข้อมูล |
| 28 | `        <input name="id" placeholder="match_id" required />` | ช่องกรอกข้อมูลในฟอร์ม |
| 29 | `        <input name="home_score" type="number" placeholder="home" required />` | ช่องกรอกข้อมูลในฟอร์ม |
| 30 | `        <input name="away_score" type="number" placeholder="away" required />` | ช่องกรอกข้อมูลในฟอร์ม |
| 31 | `        <select name="status" id="statusSel">` | แท็ก/ข้อความ HTML อื่น ๆ |
| 32 | `          <option>finished</option>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 33 | `          <option>live</option>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 34 | `          <option>scheduled</option>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 35 | `          <option>canceled</option>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 36 | `        </select>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 37 | `        <button>Update</button>` | ปุ่มกด |
| 38 | `      </form>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 39 | `    </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 40 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 41 | `    <script src="_common.js"></script>` | ฝัง/ลิงก์สคริปต์ JavaScript |
| 42 | `    <script>` | ฝัง/ลิงก์สคริปต์ JavaScript |
| 43 | `      document.getElementById("nav").innerHTML = navBar("matches"); // หรือ matches/events/standings ตามหน้า` | แท็ก/ข้อความ HTML อื่น ๆ |
| 44 | `      bindLogout();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 45 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 46 | `      // Gate for guests` | แท็ก/ข้อความ HTML อื่น ๆ |
| 47 | `      if (!me()) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 48 | `        // ซ่อนคอนเทนต์ทั้งหมดของเพจ (ยกเว้น nav และ H1)` | แท็ก/ข้อความ HTML อื่น ๆ |
| 49 | `        [...document.body.children].forEach((el) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 50 | `          if (el.id === "nav") return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 51 | `          if (el.tagName === "H1") return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 52 | `          el.style.display = "none";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 53 | `        });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 54 | `        // แปะข้อความเตือนใต้หัวข้อ` | แท็ก/ข้อความ HTML อื่น ๆ |
| 55 | `        (document.querySelector("h1") \|\| document.body).insertAdjacentHTML(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 56 | `          "beforeend",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 57 | `          `<div class="guest-message">ต้องเข้าสู่ระบบก่อนเพื่อดูข้อมูล</div>`` | แท็ก/ข้อความ HTML อื่น ๆ |
| 58 | `        );` | แท็ก/ข้อความ HTML อื่น ๆ |
| 59 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 60 | `        // กันสคริปต์ส่วนถัดไปของหน้านี้ไม่ให้รันต่อ` | แท็ก/ข้อความ HTML อื่น ๆ |
| 61 | `        throw new Error("GUEST_BLOCKED_MATCHES");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 62 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 63 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 64 | `      const statusSel = document.getElementById("statusSel");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 65 | `      const homeInput = document.querySelector("form#score [name=home_score]");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 66 | `      const awayInput = document.querySelector("form#score [name=away_score]");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 67 | `      document.getElementById("nav").innerHTML = navBar("matches");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 68 | `      function toggleScoreInputs() {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 69 | `        const isCanceled = statusSel.value === "canceled";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 70 | `        homeInput.disabled = isCanceled;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 71 | `        awayInput.disabled = isCanceled;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 72 | `        homeInput.required = !isCanceled;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 73 | `        awayInput.required = !isCanceled;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 74 | `        if (isCanceled) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 75 | `          homeInput.value = "";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 76 | `          awayInput.value = "";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 77 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 78 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 79 | `      statusSel.addEventListener("change", toggleScoreInputs);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 80 | `      toggleScoreInputs();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 81 | `      bindLogout();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 82 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 83 | `      async function fetchJSON(url, options = {}) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 84 | `        const r = await fetch(url, options);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 85 | `        if (!r.ok) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 86 | `          let msg = `HTTP ${r.status}`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 87 | `          try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 88 | `            const d = await r.json();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 89 | `            msg = d.error \|\| d.message \|\| msg;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 90 | `          } catch {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 91 | `            try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 92 | `              msg = (await r.text()) \|\| msg;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 93 | `            } catch {}` | แท็ก/ข้อความ HTML อื่น ๆ |
| 94 | `          }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 95 | `          const err = new Error(msg);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 96 | `          err.status = r.status;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 97 | `          throw err;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 98 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 99 | `        try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 100 | `          return await r.json();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 101 | `        } catch {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 102 | `          return null;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 103 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 104 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 105 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 106 | `      async function load() {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 107 | `        const fx = await fetchJSON("/api/matches");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 108 | `        const isAdm = isAdmin();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 109 | `        document.getElementById("list").innerHTML =` | แท็ก/ข้อความ HTML อื่น ๆ |
| 110 | `          (fx \|\| [])` | แท็ก/ข้อความ HTML อื่น ๆ |
| 111 | `            .map(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 112 | `              (m) => `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 113 | `      <div data-id="${m.id}">` | คอนเทนเนอร์กลุ่มองค์ประกอบ (div) |
| 114 | `        ${m.id}. ${new Date(m.tipoff_at).toLocaleString()}` | แท็ก/ข้อความ HTML อื่น ๆ |
| 115 | `        — ${m.home_name} ${m.home_score}:${m.away_score} ${m.away_name}` | แท็ก/ข้อความ HTML อื่น ๆ |
| 116 | `        @ ${m.venue \|\| "-"} [${m.status}]` | แท็ก/ข้อความ HTML อื่น ๆ |
| 117 | `        ${` | แท็ก/ข้อความ HTML อื่น ๆ |
| 118 | `          isAdm` | แท็ก/ข้อความ HTML อื่น ๆ |
| 119 | `            ? `<button class="del" style="margin-left:6px">Delete</button>`` | แท็ก/ข้อความ HTML อื่น ๆ |
| 120 | `            : ""` | แท็ก/ข้อความ HTML อื่น ๆ |
| 121 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 122 | `      </div>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 123 | `    `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 124 | `            )` | แท็ก/ข้อความ HTML อื่น ๆ |
| 125 | `            .join("") \|\| "<em>No matches</em>";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 126 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 127 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 128 | `      async function loadTeams() {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 129 | `        const teams = await fetchJSON("/api/teams");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 130 | `        const opts = teams` | แท็ก/ข้อความ HTML อื่น ๆ |
| 131 | `          .map(` | แท็ก/ข้อความ HTML อื่น ๆ |
| 132 | `            (t) =>` | แท็ก/ข้อความ HTML อื่น ๆ |
| 133 | `              `<option value="${t.id}">${t.short_code \|\| t.name} — ${` | แท็ก/ข้อความ HTML อื่น ๆ |
| 134 | `                t.name` | แท็ก/ข้อความ HTML อื่น ๆ |
| 135 | `              }</option>`` | แท็ก/ข้อความ HTML อื่น ๆ |
| 136 | `          )` | แท็ก/ข้อความ HTML อื่น ๆ |
| 137 | `          .join("");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 138 | `        document.getElementById("homeTeam").innerHTML = opts;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 139 | `        document.getElementById("awayTeam").innerHTML = opts;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 140 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 141 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 142 | `      if (isAdmin()) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 143 | `        document.getElementById("admin").style.display = "block";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 144 | `        loadTeams();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 145 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 146 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 147 | `      // Create match` | แท็ก/ข้อความ HTML อื่น ๆ |
| 148 | `      document.getElementById("create").onsubmit = async (e) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 149 | `        e.preventDefault();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 150 | `        const msg = document.getElementById("msg");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 151 | `        msg.textContent = "";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 152 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 153 | `        const f = Object.fromEntries(new FormData(e.target));` | แท็ก/ข้อความ HTML อื่น ๆ |
| 154 | `        const body = {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 155 | `          home_team_id: Number(f.home_team_id),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 156 | `          away_team_id: Number(f.away_team_id),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 157 | `          tipoff_at: f.tipoff_at,` | แท็ก/ข้อความ HTML อื่น ๆ |
| 158 | `          venue: f.venue \|\| null,` | แท็ก/ข้อความ HTML อื่น ๆ |
| 159 | `        };` | แท็ก/ข้อความ HTML อื่น ๆ |
| 160 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 161 | `        // validate` | แท็ก/ข้อความ HTML อื่น ๆ |
| 162 | `        if (!body.home_team_id \|\| !body.away_team_id) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 163 | `          msg.textContent = "เลือกทีมให้ครบ";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 164 | `          return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 165 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 166 | `        if (body.home_team_id === body.away_team_id) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 167 | `          msg.textContent = "ห้ามทีมเหย้า/เยือนเป็นทีมเดียวกัน";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 168 | `          return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 169 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 170 | `        if (!body.tipoff_at) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 171 | `          msg.textContent = "กรอกวันเวลาแข่งขัน";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 172 | `          return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 173 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 174 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 175 | `        try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 176 | `          const created = await fetchJSON("/api/matches", {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 177 | `            method: "POST",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 178 | `            headers: { "Content-Type": "application/json", ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 179 | `            body: JSON.stringify(body),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 180 | `          });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 181 | `          msg.style.color = "#0a0";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 182 | `          msg.textContent = `Created match #${created.id}`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 183 | `          e.target.reset();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 184 | `          await load();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 185 | `        } catch (err) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 186 | `          msg.style.color = "#d33";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 187 | `          msg.textContent = err.message;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 188 | `          if (err.status === 401) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 189 | `            localStorage.removeItem("token");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 190 | `            location.href = "login.html";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 191 | `          }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 192 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 193 | `      };` | แท็ก/ข้อความ HTML อื่น ๆ |
| 194 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 195 | `      // Update score/status` | แท็ก/ข้อความ HTML อื่น ๆ |
| 196 | `      document.getElementById("score").onsubmit = async (e) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 197 | `        e.preventDefault();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 198 | `        const msg = document.getElementById("msg");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 199 | `        msg.textContent = "";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 200 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 201 | `        const f = Object.fromEntries(new FormData(e.target));` | แท็ก/ข้อความ HTML อื่น ๆ |
| 202 | `        const isCanceled = f.status === "canceled";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 203 | `        const body = isCanceled` | แท็ก/ข้อความ HTML อื่น ๆ |
| 204 | `          ? { status: "canceled" } // ส่งเฉพาะสถานะ` | แท็ก/ข้อความ HTML อื่น ๆ |
| 205 | `          : {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 206 | `              home_score: Number(f.home_score),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 207 | `              away_score: Number(f.away_score),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 208 | `              status: f.status,` | แท็ก/ข้อความ HTML อื่น ๆ |
| 209 | `            };` | แท็ก/ข้อความ HTML อื่น ๆ |
| 210 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 211 | `        try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 212 | `          await fetchJSON(`/api/matches/${Number(f.id)}/score`, {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 213 | `            method: "PUT",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 214 | `            headers: { "Content-Type": "application/json", ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 215 | `            body: JSON.stringify(body),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 216 | `          });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 217 | `          msg.style.color = "#0a0";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 218 | `          msg.textContent = "Updated";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 219 | `          e.target.reset();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 220 | `          toggleScoreInputs(); // รีเซ็ต + ปรับ state ปุ่ม` | แท็ก/ข้อความ HTML อื่น ๆ |
| 221 | `          await load();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 222 | `        } catch (err) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 223 | `          msg.style.color = "#d33";` | แท็ก/ข้อความ HTML อื่น ๆ |
| 224 | `          msg.textContent = err.message;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 225 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 226 | `      };` | แท็ก/ข้อความ HTML อื่น ๆ |
| 227 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 228 | `      load();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 229 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 230 | `      // handler ลบ` | แท็ก/ข้อความ HTML อื่น ๆ |
| 231 | `      document.getElementById("list").addEventListener("click", async (e) => {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 232 | `        if (!e.target.classList.contains("del")) return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 233 | `        const div = e.target.closest("div[data-id]");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 234 | `        const id = Number(div.dataset.id);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 235 | `        if (!confirm(`Delete match #${id}?`)) return;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 236 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 237 | `        try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 238 | `          const r = await fetch(`/api/matches/${id}`, {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 239 | `            method: "DELETE",` | แท็ก/ข้อความ HTML อื่น ๆ |
| 240 | `            headers: { ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 241 | `          });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 242 | `          if (!r.ok) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 243 | `            let msg = `HTTP ${r.status}`;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 244 | `            try {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 245 | `              msg = (await r.json()).error \|\| msg;` | แท็ก/ข้อความ HTML อื่น ๆ |
| 246 | `            } catch {}` | แท็ก/ข้อความ HTML อื่น ๆ |
| 247 | `            throw new Error(msg);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 248 | `          }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 249 | `          await load();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 250 | `        } catch (err) {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 251 | `          alert(err.message);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 252 | `        }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 253 | `      });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 254 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 255 | `      async function updateScore() {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 256 | `        const matchId = Number(document.getElementById("matchId").value);` | แท็ก/ข้อความ HTML อื่น ๆ |
| 257 | `        const score = document.getElementById("score").value; // เช่น "100-135"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 258 | `        const status = document.getElementById("status").value; // "finished"` | แท็ก/ข้อความ HTML อื่น ๆ |
| 259 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 260 | `        const r = await fetch(`/api/matches/${matchId}/score`, {` | แท็ก/ข้อความ HTML อื่น ๆ |
| 261 | `          method: "POST", // หรือ 'PUT'` | แท็ก/ข้อความ HTML อื่น ๆ |
| 262 | `          headers: { "Content-Type": "application/json", ...authHeaders() },` | แท็ก/ข้อความ HTML อื่น ๆ |
| 263 | `          body: JSON.stringify({ score, status }),` | แท็ก/ข้อความ HTML อื่น ๆ |
| 264 | `        });` | แท็ก/ข้อความ HTML อื่น ๆ |
| 265 | `        const d = await r.json();` | แท็ก/ข้อความ HTML อื่น ๆ |
| 266 | `        if (!r.ok) return alert(d.error \|\| "Update failed");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 267 | `        alert("Score updated");` | แท็ก/ข้อความ HTML อื่น ๆ |
| 268 | `      }` | แท็ก/ข้อความ HTML อื่น ๆ |
| 269 | `` | แท็ก/ข้อความ HTML อื่น ๆ |
| 270 | `    </script>` | ปิดสคริปต์ |
| 271 | `  </body>` | ปิด body |
| 272 | `</html>` | ปิดเอกสาร HTML |
