# style.css — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `/* public/css/style.css */` | คอมเมนต์อธิบายใน CSS |
| 2 | `body { font-family: system-ui, sans-serif; margin: 24px; }` | คุณสมบัติสไตล์ (property: value) |
| 3 | `h1, h2 { margin: 12px 0; }` | คุณสมบัติสไตล์ (property: value) |
| 4 | `section { margin-top: 20px; }` | คุณสมบัติสไตล์ (property: value) |
| 5 | `#seats button { margin: 4px; padding: 8px 10px; }` | คุณสมบัติสไตล์ (property: value) |
| 6 | `nav a { margin-right: 8px; }` | คุณสมบัติสไตล์ (property: value) |
| 7 | `` | กฎ/นิพจน์ CSS ทั่วไป |
| 8 | `.guest-message {` | ตัวเลือก (selector) ขององค์ประกอบที่จะกำหนดสไตล์ |
| 9 | `    padding: 24px 0 0 32px;  /* ระยะห่างบน-ล่าง-ซ้ายให้เท่ากันทุกหน้า */` | คุณสมบัติสไตล์ (property: value) |
| 10 | `    color: #444;` | คุณสมบัติสไตล์ (property: value) |
| 11 | `    font-size: 15px;` | คุณสมบัติสไตล์ (property: value) |
| 12 | `}` | ปิดบล็อกกฎของ CSS |
| 13 | `` | กฎ/นิพจน์ CSS ทั่วไป |
| 14 | `` | กฎ/นิพจน์ CSS ทั่วไป |
| 15 | `/* ========== Global Layout ========== */` | คอมเมนต์อธิบายใน CSS |
| 16 | `:root { --gap: 12px; }` | คุณสมบัติสไตล์ (property: value) |
| 17 | `body { font-family: system-ui, sans-serif; margin: 24px; }` | คุณสมบัติสไตล์ (property: value) |
| 18 | `h1, h2, h3, h4 { margin: 12px 0; }` | คุณสมบัติสไตล์ (property: value) |
| 19 | `section { margin-top: 20px; }` | คุณสมบัติสไตล์ (property: value) |
| 20 | `nav { display: flex; gap: 12px; align-items: center; margin-bottom: 16px; }` | คุณสมบัติสไตล์ (property: value) |
| 21 | `` | กฎ/นิพจน์ CSS ทั่วไป |
| 22 | `/* Reusable UI */` | คอมเมนต์อธิบายใน CSS |
| 23 | `.pill { padding: 2px 8px; border-radius: 12px; background: #eee; font-size: 12px; }` | คุณสมบัติสไตล์ (property: value) |
| 24 | `.card { border: 1px solid #ddd; border-radius: 10px; padding: 12px; margin: 10px 0; }` | คุณสมบัติสไตล์ (property: value) |
| 25 | `.row { display: flex; gap: 10px; align-items: center; }` | คุณสมบัติสไตล์ (property: value) |
| 26 | `.muted { color: #666; font-size: 12px; }` | คุณสมบัติสไตล์ (property: value) |
| 27 | `.btn { padding: 6px 10px; border: 1px solid #ccc; border-radius: 8px; background: #fafafa; cursor: pointer; }` | คุณสมบัติสไตล์ (property: value) |
| 28 | `.btn[disabled] { opacity: .5; cursor: not-allowed; }` | คุณสมบัติสไตล์ (property: value) |
| 29 | `.box { border: 1px solid #e6e6e6; border-radius: 8px; padding: 8px; margin: 8px 0; }` | คุณสมบัติสไตล์ (property: value) |
| 30 | `` | กฎ/นิพจน์ CSS ทั่วไป |
| 31 | `/* Seats grid */` | คอมเมนต์อธิบายใน CSS |
| 32 | `#seats { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 12px; }` | คุณสมบัติสไตล์ (property: value) |
| 33 | `#seats button { margin: 4px; padding: 8px 10px; border: 1px solid #ccc; border-radius: 8px; }` | คุณสมบัติสไตล์ (property: value) |
| 34 | `#seats button[disabled] { opacity: .5; cursor: not-allowed; }` | คุณสมบัติสไตล์ (property: value) |
| 35 | `` | กฎ/นิพจน์ CSS ทั่วไป |
| 36 | `/* Tables */` | คอมเมนต์อธิบายใน CSS |
| 37 | `table { width: 100%; border-collapse: collapse; }` | คุณสมบัติสไตล์ (property: value) |
| 38 | `th, td { padding: 6px 8px; border-bottom: 1px solid #eee; text-align: left; }` | คุณสมบัติสไตล์ (property: value) |
| 39 | `` | กฎ/นิพจน์ CSS ทั่วไป |
| 40 | `/* Guest message */` | คอมเมนต์อธิบายใน CSS |
| 41 | `.guest-message { padding: 16px; color: #444; margin-top: 8px; }` | คุณสมบัติสไตล์ (property: value) |
