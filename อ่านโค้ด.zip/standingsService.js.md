# standingsService.js — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `const pool = require('../db');` | นำเข้าโมดูลด้วย CommonJS (`require`) แล้วเก็บในตัวแปร `const` |
| 2 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 3 | `async function rebuildStandings() {` | ประกาศฟังก์ชันแบบ async รองรับ await |
| 4 | `  const client = await pool.connect();` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 5 | `  try {` | เริ่มบล็อก try เพื่อดักจับข้อผิดพลาด |
| 6 | `    await client.query('BEGIN');` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 7 | `    await client.query('TRUNCATE standings');` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 8 | `    await client.query('INSERT INTO standings(team_id) SELECT id FROM teams');` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 9 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 10 | `    const { rows } = await client.query(`` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 11 | `      SELECT home_team_id h, away_team_id a, home_score hs, away_score as` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 12 | `      FROM matches WHERE status='finished'` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 13 | `    `);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 14 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 15 | `    for (const r of rows) {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 16 | `      const win = r.hs > r.as ? r.h : r.a;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 17 | `      const lose = r.hs > r.as ? r.a : r.h;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 18 | `      const wpf = Math.max(r.hs, r.as), wpa = Math.min(r.hs, r.as);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 19 | `      const lpf = wpa, lpa = wpf;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 20 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 21 | `      await client.query(`` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 22 | `        UPDATE standings SET games_played=games_played+1, wins=wins+1,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 23 | `          points_for=points_for+$1, points_against=points_against+$2` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 24 | `        WHERE team_id=$3` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 25 | `      `, [wpf, wpa, win]);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 26 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 27 | `      await client.query(`` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 28 | `        UPDATE standings SET games_played=games_played+1, losses=losses+1,` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 29 | `          points_for=points_for+$1, points_against=points_against+$2` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 30 | `        WHERE team_id=$3` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 31 | `      `, [lpf, lpa, lose]);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 32 | `    }` | ปิดบล็อก/ปิดคำสั่ง |
| 33 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 34 | `    await client.query(`` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 35 | `      UPDATE standings` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 36 | `      SET win_pct = CASE WHEN games_played=0 THEN 0` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 37 | `                         ELSE ROUND(wins::numeric/games_played, 3) END` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 38 | `    `);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 39 | `    await client.query('COMMIT');` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 40 | `  } catch (e) {` | จับข้อผิดพลาด (exception) ที่เกิดในบล็อก try |
| 41 | `    await client.query('ROLLBACK');` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 42 | `    throw e;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 43 | `  } finally {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 44 | `    client.release();` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 45 | `  }` | ปิดบล็อก/ปิดคำสั่ง |
| 46 | `}` | ปิดบล็อก/ปิดคำสั่ง |
| 47 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 48 | `module.exports = { rebuildStandings };` | ส่งออกค่าจากไฟล์ (CommonJS) ให้ไฟล์อื่น `require` ไปใช้ |
