# fileAuth.js — อธิบายโค้ดทีละบรรทัด
| บรรทัด | โค้ด | คำอธิบาย |
|---:|---|---|
| 1 | `const fs = require('fs');` | นำเข้าโมดูลด้วย CommonJS (`require`) แล้วเก็บในตัวแปร `const` |
| 2 | `const path = require('path');` | นำเข้าโมดูลด้วย CommonJS (`require`) แล้วเก็บในตัวแปร `const` |
| 3 | `const bcrypt = require('bcrypt');` | นำเข้าโมดูลด้วย CommonJS (`require`) แล้วเก็บในตัวแปร `const` |
| 4 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 5 | `const FILE = path.join(__dirname, '..', 'auth', 'users.json');` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 6 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 7 | `function readUsers() {` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 8 | `  const raw = fs.readFileSync(FILE, 'utf-8');` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 9 | `  return JSON.parse(raw).users \|\| [];` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 10 | `}` | ปิดบล็อก/ปิดคำสั่ง |
| 11 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 12 | `async function verifyUser(username, password) {` | ประกาศฟังก์ชันแบบ async รองรับ await |
| 13 | `  const u = readUsers().find(x => x.username === username);` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 14 | `  if (!u) return null;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 15 | `  const ok = await bcrypt.compare(password, u.passwordHash);` | รอผลลัพธ์แบบอะซิงก์ด้วย `await` |
| 16 | `  if (!ok) return null;` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 17 | `  return { username: u.username, roles: u.roles \|\| [], groups: u.groups \|\| [] };` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 18 | `}` | ปิดบล็อก/ปิดคำสั่ง |
| 19 | `` | คำสั่ง JavaScript ทั่วไป (กำหนดตัวแปร/นิพจน์/โครงสร้างควบคุม) |
| 20 | `module.exports = { verifyUser };` | ส่งออกค่าจากไฟล์ (CommonJS) ให้ไฟล์อื่น `require` ไปใช้ |
