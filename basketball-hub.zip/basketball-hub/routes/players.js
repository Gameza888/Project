const express = require('express');
const router = express.Router();
const pool = require('../db');
const { requireAuth } = require('../middleware/auth');
const { hasRole } = require('../middleware/rbac');

// GET players
router.get('/', async (_req, res) => {
  const { rows } = await pool.query(`
    SELECT p.*, t.name AS team_name
    FROM players p
    JOIN teams t ON t.id = p.team_id
    ORDER BY p.id DESC
  `);
  res.json(rows);
});

// CREATE player (admin)
router.post('/', requireAuth, hasRole('admin'), async (req, res) => {
  const { team_id, first_name, last_name, position, jersey_number } = req.body;
  if (!team_id) return res.status(400).json({ error: 'team_id is required' });

  try {
    const { rows } = await pool.query(
      `INSERT INTO players (team_id, first_name, last_name, position, jersey_number)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [Number(team_id), first_name || null, last_name || null, position || null, jersey_number ? Number(jersey_number) : null]
    );
    res.status(201).json(rows[0]);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

module.exports = router;
