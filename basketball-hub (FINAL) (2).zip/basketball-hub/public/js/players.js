// Public/js/players.js
const { requireAuth } = require('../middleware/auth');
const { hasRole } = require('../middleware/rbac');

// ... (GET เดิมคงไว้)

router.post('/', requireAuth, hasRole('admin'), async (req, res) => {
  const { team_id, first_name, last_name, position, jersey_number } = req.body;
  try {
    const { rows } = await pool.query(
      `INSERT INTO players(team_id, first_name, last_name, position, jersey_number)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [team_id, first_name, last_name, position, jersey_number]
    );
    res.status(201).json(rows[0]);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
